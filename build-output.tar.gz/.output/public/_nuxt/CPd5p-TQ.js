function d(e,r){return e}export{d as b};
