import{d as ie,a as le,b as pe,c as de,e as B}from"./DAINh1XZ.js";function C(e){return Array.from(e.toLowerCase()).filter(t=>/[a-z0-9\u4e00-\u9fa5]/.test(t)).join("")}function P(e){const t=e.toLowerCase().split(/[^a-z0-9\u4e00-\u9fa5]+/).map(r=>r.trim()).filter(r=>r.length>=2),o=e.match(/[\u4e00-\u9fa5]{2,}/g)??[],n=[];for(const r of o){if(r.length<=4){n.push(r);continue}for(let s=0;s<r.length-1;s+=1)n.push(r.slice(s,s+2))}return Array.from(new Set([...t,...n])).filter(r=>r.length>=2)}function S(e,t,o){const n=C(e);if(!n)return 0;let r=0;const s=C(t);s&&n.includes(s)&&(r+=10);for(const l of o){const i=C(l);i&&n.includes(i)&&(r+=2)}return r}function L(e,t,o){const n=P(t);return[...e].map(r=>({item:r,score:S(o(r),t,n)})).filter(r=>r.score>0).sort((r,s)=>s.score-r.score).map(r=>r.item)}function Q(e){return e==="webpage"?"网页":e==="email"?"邮件":e==="excel"?"表格":"文档"}function ue(e){return[e.title,e.category,e.summary,e.content,e.sourceLabel,e.sourceUrl,...e.tags??[],...e.faqQuestions??[],...e.answerHints??[]].filter(Boolean).join(" ")}function ge(e){return e.filter(t=>t.enabled!==!1)}function Y(e){const t=e.replace(/\r/g,`
`).trim();if(!t)return[];const o=t.split(/\n{2,}/).map(s=>s.replace(/\s+/g," ").trim()).filter(Boolean),n=o.length?o:t.split(/[。！？!?；;\n]+/).map(s=>s.replace(/\s+/g," ").trim()),r=[];for(const s of n.filter(Boolean)){if(s.length<=140){r.push(s);continue}for(let l=0;l<s.length;l+=120){const i=s.slice(l,l+120).trim();i&&r.push(i)}}return r.slice(0,24)}function fe(e,t){const o=Y(e.content);if(!o.length)return e.summary.trim();const n=P(t),r=o.map(s=>({segment:s,score:S(s,t,n)})).sort((s,l)=>l.score-s.score);return r[0]?.score?r[0].segment:o[0]}function be(e,t){const o=P(e);return[...ge(t)].map(n=>{const r=S(ue(n),e,o),s=Y(n.content).reduce((u,d)=>Math.max(u,S(d,e,o)),0),l=(n.faqQuestions??[]).reduce((u,d)=>u+S(d,e,o)*2,0),i=(n.answerHints??[]).reduce((u,d)=>u+S(d,e,o),0);return{item:n,score:r+s*2+l+i}}).filter(n=>n.score>0).sort((n,r)=>r.score-n.score).slice(0,3).map(n=>n.item)}function me(e,t){const o=fe(e,t).replace(/\s+/g," ").trim();if(!o)return e.summary.trim();const r=[t,...P(t)].map(u=>u.trim()).filter(Boolean).find(u=>o.toLowerCase().includes(u.toLowerCase()));if(!r)return o.slice(0,120);const s=o.toLowerCase().indexOf(r.toLowerCase()),l=Math.max(0,s-24),i=Math.min(o.length,s+r.length+48);return o.slice(l,i)}function he(e,t){const o=P(t),n=C(t),r=[e.title,e.oneLiner,e.whatIs,...e.problems,...e.workflow,...e.scenarios,...e.outcomes].join(" ");let s=S(r,t,o);for(const l of e.keywords){const i=C(l);i&&n.includes(i)&&(s+=8)}return s}function xe(e,t){const o=C(t);return o?e.keywords.some(n=>{const r=C(n);return r.length>=2&&o.includes(r)}):!1}function ye(e,t){const n=t.map(r=>{const s=he(r,e),l=r.source==="faq-standard-reply"&&xe(r,e)?24:0;return{entry:r,score:s+l}}).sort((r,s)=>s.score-r.score)[0];return!n||n.score<8?null:n.entry}function we(e,t){const o=["基于当前资料，结构化答复如下：",`【你的问题】${t}`,`【主题】${e.title}`,`【一句话】${e.oneLiner}`,`【它是什么】${e.whatIs}`,"【主要解决】"];return e.problems.forEach(n=>{o.push(`- ${n}`)}),o.push("【落地流程】"),e.workflow.forEach((n,r)=>{o.push(`${r+1}. ${n}`)}),o.push("【适用场景】"),e.scenarios.forEach(n=>{o.push(`- ${n}`)}),o.push("【预期效果】"),e.outcomes.forEach(n=>{o.push(`- ${n}`)}),o.push("【参考资料】"),o.push(`- 知识条目：${e.title}`),o.push(`- 来源：${e.source}`),o.join(`
`)}function ve(e){return e.negotiable||!e.price.trim()?"面议":e.price.startsWith("¥")||e.price.startsWith("￥")?e.price:`¥${e.price}`}function $e(e){const{query:t,products:o,consultingServices:n}=e,r=L(o,t,i=>`${i.name} ${i.category} ${i.summary}`).slice(0,8),s=L(n,t,i=>`${i.name} ${i.category} ${i.introduction}`).slice(0,5);if(r.length===0&&s.length===0)return`暂无精确匹配。你可以试试这些示例：${o.slice(0,3).map(u=>u.name).join("、")||"六角头螺栓、高速螺丝机"}。`;const l=["已检索到以下价格信息："];return r.forEach(i=>{l.push(`- [${i.category}] ${i.name}：${i.priceText}`),i.parameters?.length&&l.push(`  参数：${i.parameters.map(u=>`${u.label}=${u.value}`).join("；")}`)}),s.forEach(i=>{l.push(`- [咨询] ${i.name}：${ve(i)}`)}),l.push("【参考资料】"),r.forEach(i=>{l.push(`- 产品：${i.name}`)}),s.forEach(i=>{l.push(`- 咨询服务：${i.name}`)}),l.push("如需正式报价，请提交联系需求。"),l.join(`
`)}function ke(e){const{query:t,knowledgeEntries:o,articles:n,products:r,consultingServices:s,contentSources:l,siteConfig:i}=e,u=t.trim()||"请介绍你们的平台能力",d=ye(u,o);if(d)return{content:we(d,u),meta:{strategy:"knowledge",matchedKnowledgeEntry:d,matchedContentSources:[]}};const E=L(n,u,c=>`${c.title} ${c.summary} ${c.category}`).slice(0,3),z=L(r,u,c=>`${c.name} ${c.category} ${c.summary}`).slice(0,3),j=L(s,u,c=>`${c.name} ${c.category} ${c.introduction}`).slice(0,2),x=be(u,l),b=["基于当前资料，结构化答复如下：",`【你的问题】${u}`,`【平台定位】${i.heroTitle}`,`【服务简介】${i.about}`];return E.length===0&&z.length===0&&j.length===0&&x.length===0?(b.push("【说明】当前资料没有直接命中该问题。可以补充知识条目后再回答。"),{content:b.join(`
`),meta:{strategy:"document",matchedKnowledgeEntry:null,matchedContentSources:[]}}):(E.length>0&&(b.push("【相关文档摘要】"),E.forEach(c=>{b.push(`- ${c.title}：${c.summary}`)})),z.length>0&&(b.push("【相关产品线索】"),z.forEach(c=>{b.push(`- ${c.name}（${c.category}）：${c.summary}`),c.parameters?.length&&b.push(`  参数：${c.parameters.map(w=>`${w.label}=${w.value}`).join("；")}`)})),j.length>0&&(b.push("【相关咨询线索】"),j.forEach(c=>{b.push(`- ${c.name}：${c.introduction}`)})),x.length>0&&(b.push("【相关资料源】"),x.forEach(c=>{b.push(`- [${Q(c.type)}] ${c.title}：${c.summary}`),c.category?.trim()&&b.push(`  分类：${c.category.trim()}`),c.answerHints?.length&&b.push(`  回答要点：${c.answerHints.join("；")}`);const w=me(c,u);w&&b.push(`  摘录：${w}`)})),b.push("【参考资料】"),E.forEach(c=>{b.push(`- 文档：${c.title}`)}),z.forEach(c=>{b.push(`- 产品：${c.name}`)}),j.forEach(c=>{b.push(`- 咨询服务：${c.name}`)}),x.forEach(c=>{const w=c.sourceUrl||c.sourceLabel||c.id;b.push(`- ${Q(c.type)}：${c.title} (${w})`)}),{content:b.join(`
`),meta:{strategy:"document",matchedKnowledgeEntry:null,matchedContentSources:x}})}function Se(e){return/价格|报价|多少钱|费用|预算|采购价|单价/.test(e)}function Ce(e){if(!e?.length)return"";const t=["【已收到附件】"];return e.forEach(o=>{t.push(`- ${o.name}（${Math.max(1,Math.round(o.size/1024))} KB）`)}),t.push("当前 MVP 已支持截图随会话留存；若需图像识别结论，请由客服进一步处理或接入视觉模型。"),t.join(`
`)}function Ee(e){let t,o;if(Se(e.query))t=$e({query:e.query,products:e.products,consultingServices:e.consultingServices}),o={strategy:"price",matchedKnowledgeEntry:null,matchedContentSources:[]};else{const s=ke({...e});t=s.content,o=s.meta}const n=Ce(e.attachments),r=[t,n].filter(Boolean).join(`

`);return e.returnMeta?{content:r,meta:o}:r}const D="customer-bot:history:v1";function K(){return{md:[],price:[],contact:[]}}function ze(e){return e==="user"||e==="assistant"?e:null}function je(e){if(!e||typeof e!="object")return null;const t=e;return typeof t.id!="string"||!t.id||typeof t.name!="string"||typeof t.mimeType!="string"||typeof t.size!="number"||typeof t.dataUrl!="string"?null:{id:t.id,name:t.name,mimeType:t.mimeType,size:t.size,dataUrl:t.dataUrl}}function Ie(e){if(!e||typeof e!="object")return null;const t=e,o=ze(t.role);return!o||typeof t.content!="string"?null:{id:typeof t.id=="string"&&t.id?t.id:`${o}-${Date.now()}`,role:o,content:t.content,createdAt:typeof t.createdAt=="number"?t.createdAt:Date.now(),attachments:Array.isArray(t.attachments)?t.attachments.map(n=>je(n)).filter(n=>!!n):void 0}}function Ae(e){const t=K();if(!e||typeof e!="object")return t;for(const o of Object.keys(t)){const n=e[o];Array.isArray(n)&&(t[o]=n.map(r=>Ie(r)).filter(r=>!!r))}return t}function Te(e=globalThis.localStorage){return{load(){if(!e)return K();try{const t=e.getItem(D);return t?Ae(JSON.parse(t)):K()}catch{return K()}},save(t){if(e)try{e.setItem(D,JSON.stringify(t))}catch{}},clear(){if(e)try{e.removeItem(D)}catch{}}}}function Le(){let e=null;return{mount(t){e||(e=document.createElement("div"),e.className="cbot-iframe-host",e.innerHTML=`
        <iframe
          title="Customer Bot"
          src="${t.iframeSrc}"
          style="position:fixed;right:16px;bottom:16px;width:380px;height:640px;border:0;border-radius:16px;box-shadow:0 20px 52px rgba(20,33,61,.2);z-index:9999;background:#fff;"
        ></iframe>
      `,document.body.appendChild(e))},destroy(){e?.remove(),e=null}}}function Pe(e){return{async reply(t){async function o(){return{content:await e.fallback(t),model:e.model||"",inputTokens:0,outputTokens:0,totalTokens:0,status:"fallback"}}if(!e.endpoint||!e.apiKey||!e.model)return o();try{const n=e.fetcher||fetch,r=e.soulProfile?[e.soulProfile.role?`角色：${e.soulProfile.role}`:"",e.soulProfile.tone?`语气：${e.soulProfile.tone}`:"",e.soulProfile.goals?.length?`目标：${e.soulProfile.goals.join("；")}`:""].filter(Boolean).join(`
`):"",s=[{role:"system",content:[e.systemPrompt||"",r].filter(Boolean).join(`

`)},...(t.history||[]).map(d=>({role:d.role,content:d.content})),{role:"user",content:[t.context||"",t.message].filter(Boolean).join(`

`)}],l=await n(e.endpoint,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e.apiKey}`},body:JSON.stringify({model:e.model,messages:s})});if(!l.ok)return o();const i=await l.json(),u=i.choices?.[0]?.message?.content?.trim();return u?{content:u,model:e.model,inputTokens:i.usage?.prompt_tokens||0,outputTokens:i.usage?.completion_tokens||0,totalTokens:i.usage?.total_tokens||0,status:"success"}:o()}catch{return o()}}}}const J="customer-bot-style";function qe(e){return e.replace(/\/+$/,"")}function R(e,t){const o=e.startsWith("/")?e:`/${e}`;return t?`${qe(t)}${o}`:o}function Me(e){if(document.getElementById(J))return;const o=document.createElement("style");o.id=J,o.textContent=`
    .cbot-root {
      position: fixed;
      right: 20px;
      bottom: 20px;
      z-index: 9999;
      font-family: "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
      color: #102132;
      width: min(420px, calc(100vw - 24px));
    }
    .cbot-root[data-open="true"] .cbot-trigger {
      opacity: 0;
      pointer-events: none;
      transform: translateY(10px) scale(.98);
    }
    .cbot-trigger {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      border: 0;
      border-radius: 999px;
      background: linear-gradient(135deg, ${e}, #0b5f7d);
      color: #fff;
      padding: 12px 16px 12px 14px;
      cursor: pointer;
      box-shadow: 0 18px 40px rgba(9, 45, 65, 0.28);
      transition: transform .18s ease, box-shadow .18s ease, opacity .18s ease;
      overflow: hidden;
    }
    .cbot-trigger::after {
      content: "";
      position: absolute;
      inset: auto -40% -55% auto;
      width: 120px;
      height: 120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(255,255,255,.28), transparent 62%);
      pointer-events: none;
    }
    .cbot-trigger:hover {
      transform: translateY(-2px);
      box-shadow: 0 24px 46px rgba(9, 45, 65, 0.34);
    }
    .cbot-trigger-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      font-size: 16px;
      flex: none;
    }
    .cbot-trigger-copy {
      display: grid;
      gap: 2px;
      text-align: left;
    }
    .cbot-trigger-title {
      font-size: 14px;
      font-weight: 700;
      line-height: 1.1;
    }
    .cbot-trigger-meta {
      font-size: 11px;
      line-height: 1.1;
      opacity: 0.82;
    }
    .cbot-trigger-status {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      margin-left: 4px;
      padding: 6px 10px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.16);
      font-size: 11px;
      font-weight: 700;
      line-height: 1;
      white-space: nowrap;
    }
    .cbot-trigger-status::before {
      content: "";
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #8cf0bd;
      box-shadow: 0 0 0 4px rgba(140, 240, 189, 0.16);
      flex: none;
    }
    .cbot-panel {
      display: none;
      width: 100%;
      height: min(720px, calc(100vh - 96px));
      margin-top: 12px;
      border: 1px solid rgba(188, 207, 220, 0.9);
      border-radius: 26px;
      background:
        radial-gradient(circle at top right, rgba(17, 138, 178, 0.12), transparent 34%),
        linear-gradient(180deg, #fcfeff, #f5f9fc 100%);
      overflow: hidden;
      box-shadow: 0 26px 70px rgba(20, 33, 61, 0.24);
      backdrop-filter: blur(8px);
    }
    .cbot-panel.is-open {
      display: grid;
      grid-template-rows: auto auto auto 1fr auto auto;
    }
    .cbot-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 14px;
      padding: 18px 18px 16px;
      background:
        radial-gradient(circle at top left, rgba(255,255,255,.38), transparent 30%),
        linear-gradient(135deg, rgba(11, 95, 125, 0.98), rgba(17, 138, 178, 0.92));
      border-bottom: 1px solid #e2e8f0;
    }
    .cbot-head-main {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      min-width: 0;
    }
    .cbot-avatar {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 44px;
      height: 44px;
      border-radius: 16px;
      background: rgba(255, 255, 255, 0.16);
      border: 1px solid rgba(255, 255, 255, 0.22);
      color: #fff;
      font-size: 14px;
      font-weight: 800;
      flex: none;
      backdrop-filter: blur(6px);
    }
    .cbot-head strong {
      display: block;
      font-size: 18px;
      line-height: 1.2;
      color: #fff;
    }
    .cbot-kicker {
      margin: 0 0 6px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(232, 246, 252, 0.82);
    }
    .cbot-subtitle {
      margin: 6px 0 0;
      font-size: 12px;
      line-height: 1.5;
      color: rgba(239, 248, 252, 0.84);
    }
    .cbot-service-line {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 10px;
    }
    .cbot-service-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 7px 10px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.14);
      border: 1px solid rgba(255, 255, 255, 0.18);
      color: #f7fdff;
      font-size: 11px;
      line-height: 1;
      white-space: nowrap;
    }
    .cbot-close {
      width: 34px;
      height: 34px;
      border: 1px solid rgba(255, 255, 255, 0.22);
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.12);
      color: #fff;
      cursor: pointer;
      flex: none;
      backdrop-filter: blur(6px);
    }
    .cbot-templates {
      display: flex;
      gap: 8px;
      padding: 12px 16px;
      border-bottom: 1px solid #edf2f7;
      overflow-x: auto;
      background: rgba(249, 251, 255, 0.8);
    }
    .cbot-overview {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 10px;
      padding: 12px 16px 14px;
      border-bottom: 1px solid #edf2f7;
      background: rgba(249, 251, 255, 0.78);
      min-width: 0;
    }
    .cbot-overview-card {
      min-width: 0;
      padding: 10px 12px;
      border: 1px solid #dbe7f0;
      border-radius: 16px;
      background: rgba(255, 255, 255, 0.88);
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.65);
    }
    .cbot-overview-card.is-emphasis {
      border-color: rgba(17, 138, 178, 0.26);
      background: linear-gradient(180deg, rgba(230, 246, 252, 0.96), rgba(255, 255, 255, 0.96));
    }
    .cbot-overview-label {
      margin: 0 0 6px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #688197;
    }
    .cbot-overview-value {
      margin: 0;
      font-size: 13px;
      line-height: 1.45;
      color: #153147;
    }
    .cbot-context {
      display: grid;
      gap: 8px;
      padding: 12px 16px 14px;
      border-bottom: 1px solid #edf2f7;
      background: linear-gradient(180deg, rgba(255, 255, 255, 0.88), rgba(248, 251, 254, 0.92));
      min-width: 0;
    }
    .cbot-context-label {
      margin: 0;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: #688197;
    }
    .cbot-context-copy {
      margin: 0;
      font-size: 13px;
      line-height: 1.6;
      color: #264156;
    }
    .cbot-welcome {
      display: grid;
      gap: 10px;
      margin-bottom: 14px;
      padding: 14px;
      border: 1px solid #dce8f1;
      border-radius: 18px;
      background: linear-gradient(180deg, rgba(255, 255, 255, 0.95), rgba(243, 248, 252, 0.96));
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.8);
    }
    .cbot-welcome-title {
      margin: 0;
      font-size: 14px;
      font-weight: 700;
      line-height: 1.4;
      color: #173247;
    }
    .cbot-welcome-copy {
      margin: 0;
      font-size: 12px;
      line-height: 1.65;
      color: #5a7489;
    }
    .cbot-welcome-list {
      display: grid;
      gap: 8px;
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .cbot-welcome-item {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      font-size: 12px;
      line-height: 1.55;
      color: #274156;
    }
    .cbot-welcome-dot {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: rgba(17, 138, 178, 0.12);
      color: #0f6f90;
      font-size: 11px;
      font-weight: 700;
      flex: none;
      margin-top: 1px;
    }
    .cbot-template-btn,
    .cbot-send,
    .cbot-contact-submit {
      border-radius: 999px;
      cursor: pointer;
      transition: transform .16s ease, border-color .16s ease, background .16s ease, color .16s ease;
    }
    .cbot-template-btn {
      padding: 7px 12px;
      background: rgba(255, 255, 255, 0.94);
      border: 1px solid #d7e3ef;
      color: #35526f;
      white-space: nowrap;
    }
    .cbot-template-btn:hover,
    .cbot-send:hover,
    .cbot-contact-submit:hover {
      transform: translateY(-1px);
    }
    .cbot-chat-log {
      display: flex;
      flex-direction: column;
      overflow: auto;
      padding: 14px 16px 10px;
      background:
        linear-gradient(180deg, rgba(250, 252, 255, 0.85), rgba(245, 250, 253, 0.92)),
        radial-gradient(circle at 0% 0%, rgba(17, 138, 178, 0.06), transparent 30%);
      min-height: 0;
    }
    .cbot-chat-stack {
      display: flex;
      flex-direction: column;
      gap: 12px;
      min-height: min-content;
    }
    .cbot-message-row {
      display: flex;
      align-items: flex-end;
      gap: 10px;
    }
    .cbot-message-row.is-user {
      justify-content: flex-end;
    }
    .cbot-message-avatar {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      border-radius: 12px;
      background: linear-gradient(135deg, rgba(17, 138, 178, 0.16), rgba(11, 95, 125, 0.14));
      color: #0f6f90;
      font-size: 11px;
      font-weight: 800;
      flex: none;
    }
    .cbot-message-row.is-user .cbot-message-avatar {
      order: 2;
      background: linear-gradient(135deg, rgba(65, 166, 220, 0.18), rgba(108, 196, 242, 0.14));
      color: #1a6e95;
    }
    .cbot-message-row.is-system .cbot-message-avatar {
      background: rgba(242, 211, 155, 0.24);
      color: #9a6818;
    }
    .cbot-message-bubble {
      display: grid;
      gap: 6px;
      max-width: calc(100% - 40px);
    }
    .cbot-message {
      display: flex;
      flex-direction: column;
      width: fit-content;
      max-width: 100%;
      margin: 0;
      padding: 12px 14px;
      border-radius: 18px 18px 18px 8px;
      border: 1px solid #d8e4ef;
      background: rgba(255, 255, 255, 0.96);
      color: #1f3349;
      white-space: pre-wrap;
      line-height: 1.5;
      font-size: 13px;
      box-shadow: 0 12px 22px rgba(19, 43, 61, 0.06);
      text-align: left;
      align-self: flex-start;
    }
    .cbot-message.is-user {
      border-radius: 18px 18px 8px 18px;
      background: linear-gradient(180deg, #e2f5ff, #d6effd);
      border-color: #abd7ee;
    }
    .cbot-message.is-system {
      max-width: 100%;
      width: auto;
      margin-right: 0;
      border-style: dashed;
      background: #fff8ea;
      border-color: #f2d39b;
      color: #7a5822;
    }
    .cbot-message-meta {
      margin: 0 0 6px;
      font-size: 11px;
      font-weight: 700;
      color: #56708a;
    }
    .cbot-message-note {
      font-size: 11px;
      line-height: 1.4;
      color: #6f8799;
      padding: 0 4px;
    }
    .cbot-message-body {
      display: grid;
      gap: 8px;
      justify-items: start;
      align-items: start;
      text-align: left;
    }
    .cbot-message-paragraph {
      margin: 0;
      width: 100%;
    }
    .cbot-chat-form,
    .cbot-contact-form {
      display: grid;
      gap: 10px;
      padding: 14px 16px 16px;
      border-top: 1px solid #edf2f7;
      background: rgba(255, 255, 255, 0.96);
    }
    .cbot-chat-form {
      grid-template-columns: 1fr auto;
      align-items: end;
      box-shadow: 0 -14px 30px rgba(19, 43, 61, 0.05);
    }
    .cbot-toolbar {
      grid-column: 1 / -1;
      display: grid;
      gap: 8px;
    }
    .cbot-input,
    .cbot-contact-form input,
    .cbot-contact-form select,
    .cbot-contact-form textarea {
      width: 100%;
      box-sizing: border-box;
      border: 1px solid #d4dce6;
      border-radius: 16px;
      padding: 12px 14px;
      font: inherit;
      background: #fff;
      color: #102132;
    }
    .cbot-input {
      min-height: 96px;
      resize: vertical;
      box-shadow: inset 0 1px 2px rgba(15, 23, 42, 0.04);
    }
    .cbot-send,
    .cbot-contact-submit {
      border: 0;
      background: linear-gradient(135deg, ${e}, #0b5f7d);
      color: #fff;
      padding: 12px 16px;
      font-weight: 700;
      min-width: 84px;
    }
    .cbot-upload-btn {
      display: inline-flex;
      align-items: center;
      width: fit-content;
      gap: 8px;
      padding: 8px 12px;
      border-radius: 999px;
      background: #ecf5fb;
      color: #35526f;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
    }
    .cbot-file-input {
      display: none;
    }
    .cbot-attachment-list {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .cbot-attachment-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 8px;
      border-radius: 12px;
      border: 1px solid #d7e3ef;
      background: #fff;
      font-size: 12px;
      color: #35526f;
    }
    .cbot-attachment-chip button {
      border: 0;
      background: transparent;
      color: #7a8fa3;
      cursor: pointer;
      padding: 0;
    }
    .cbot-message-attachments {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 8px;
    }
    .cbot-message-attachment {
      display: block;
      width: 84px;
      height: 84px;
      overflow: hidden;
      border-radius: 12px;
      border: 1px solid #d7e3ef;
      background: #eef5fb;
    }
    .cbot-message-attachment img {
      width: 100%;
      height: 100%;
      display: block;
      object-fit: cover;
    }
    .cbot-contact-panel {
      display: none;
      padding: 0 16px 16px;
      border-top: 1px solid #edf2f7;
      background: #f8fbff;
      min-width: 0;
    }
    .cbot-contact-panel.is-active {
      display: block;
    }
    .cbot-contact-meta,
    .cbot-contact-notice {
      margin: 8px 0 0;
      font-size: 12px;
      line-height: 1.5;
      color: #35526f;
      white-space: pre-wrap;
    }
    .cbot-chat-status {
      min-height: 20px;
      padding: 6px 16px 10px;
      font-size: 12px;
      line-height: 1.5;
      color: #587186;
      background: rgba(255, 255, 255, 0.96);
      border-top: 1px solid rgba(237, 242, 247, 0.7);
    }
    .cbot-chat-status.is-error {
      color: #b4491f;
    }
    .cbot-send[disabled],
    .cbot-contact-submit[disabled] {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }
    @media (max-width: 640px) {
      .cbot-root {
        right: 12px;
        left: 12px;
        bottom: 12px;
        width: auto;
      }
      .cbot-trigger {
        width: 100%;
        justify-content: center;
      }
      .cbot-panel {
        width: 100%;
        height: min(76vh, 680px);
      }
      .cbot-overview {
        grid-template-columns: 1fr;
      }
      .cbot-chat-form {
        grid-template-columns: 1fr;
      }
      .cbot-send {
        width: 100%;
      }
      .cbot-message-bubble {
        max-width: calc(100% - 8px);
      }
    }
  `,document.head.appendChild(o)}function Be(e,t){const o=document.createElement("div");return o.className="cbot-root",o.innerHTML=`
    <button type="button" class="cbot-trigger" aria-label="打开 AI 客服">
      <span class="cbot-trigger-badge">AI</span>
      <span class="cbot-trigger-copy">
        <span class="cbot-trigger-title">AI 客服</span>
        <span class="cbot-trigger-meta">文档答疑 / 报价 / 留资</span>
      </span>
      <span class="cbot-trigger-status">在线</span>
    </button>
    <section class="cbot-panel" aria-label="AI 客服">
      <header class="cbot-head">
        <div class="cbot-head-main">
          <span class="cbot-avatar">AI</span>
          <div>
            <p class="cbot-kicker">${t}</p>
            <strong>AI 客服服务台</strong>
<!--            <p class="cbot-subtitle">先回答问题，再判断价格和联系需求，减少来回确认。</p>-->
            <div class="cbot-service-line">
              <span class="cbot-service-pill">7 x 24 在线接待</span>
              <span class="cbot-service-pill">优先基于当前资料回答</span>
            </div>
          </div>
        </div>
        <button type="button" class="cbot-close" aria-label="关闭 AI 客服">×</button>
      </header>
     <!--  <section class="cbot-overview" aria-label="客服能力概览">
        <article class="cbot-overview-card is-emphasis">
          <p class="cbot-overview-label">当前站点</p>
          <p class="cbot-overview-value">${t}</p>
        </article>
        <article class="cbot-overview-card">
          <p class="cbot-overview-label">响应方式</p>
          <p class="cbot-overview-value">先答疑，再报价，再推进联系</p>
        </article>
        <article class="cbot-overview-card">
          <p class="cbot-overview-label">适用场景</p>
          <p class="cbot-overview-value">方案咨询、产品询价、合作留资</p>
        </article>
      </section>
     <section class="cbot-context" aria-live="polite">-->
<!--        <p class="cbot-context-label">当前模块说明</p>-->
<!--        <p class="cbot-context-copy"></p>-->
<!--      </section>-->
      <div class="cbot-templates"></div>
      <div class="cbot-chat-log"></div>
      <div class="cbot-chat-status" aria-live="polite"></div>
      <form class="cbot-chat-form">
        <textarea class="cbot-input" rows="2" placeholder="请输入问题"></textarea>
        <div class="cbot-toolbar">
          <label class="cbot-upload-btn">
            <input class="cbot-file-input" type="file" accept="image/*" multiple />
            截图附件
          </label>
          <div class="cbot-attachment-list"></div>
        </div>
        <button type="submit" class="cbot-send">发送</button>
      </form>
      <section class="cbot-contact-panel">
        <p class="cbot-contact-meta"></p>
        <form class="cbot-contact-form">
          <input name="name" type="text" maxlength="50" placeholder="姓名" required />
          <input name="company" type="text" maxlength="100" placeholder="公司" required />
          <input name="contact" type="text" maxlength="100" placeholder="手机号 / 邮箱 / 微信" required />
          <select name="demandType" required>
            <option value="汽车产件询价">汽车产件询价</option>
            <option value="机台设备询价">机台设备询价</option>
            <option value="项目合作咨询">项目合作咨询</option>
          </select>
          <textarea name="message" maxlength="300" rows="2" placeholder="补充需求（选填）"></textarea>
          <button type="submit" class="cbot-contact-submit">提交联系需求</button>
        </form>
        <p class="cbot-contact-notice"></p>
      </section>
    </section>
  `,Me(e),document.body.appendChild(o),o}function Ne(){let e=null,t=null,o="md",n={},r=!1;const s=Te();let l=null,i=null,u=[],d=null;const E={md:[{label:"WMS 是什么",prompt:"WMS 是怎样一回事？"},{label:"采购 AI 助手",prompt:"采购 AI 助手能解决什么问题？"},{label:"财税 OCR",prompt:"财税 OCR 怎么落地？"}],price:[{label:"六角头螺栓",prompt:"六角头螺栓多少钱？"},{label:"高速螺丝机",prompt:"高速螺丝机价格是多少？"},{label:"咨询服务",prompt:"智能工厂诊断咨询价格是多少？"}],contact:[{label:"联系方式",prompt:"请把电话和邮箱告诉我。"},{label:"最快沟通",prompt:"怎样最快联系到你们？"},{label:"提需求",prompt:"提交合作需求需要哪些信息？"}]},z={md:"适合先问系统概念、落地方式、适用场景。我会尽量基于当前租户资料给你结构化回答。",price:"适合直接问产品或服务价格。如果资料里有命中的产品参数或咨询服务，我会优先按明确价格回答。",contact:"适合准备进入人工沟通阶段时使用。你可以直接拿联系方式，或提交合作需求表单。"},j={md:{title:"先问清楚，再决定要不要继续推进",copy:"适合第一次接触方案时使用。你可以直接问概念、流程、适用场景或实施方式。",bullets:["可先问系统是什么","可追问落地步骤","可结合截图或资料继续追问"]},price:{title:"先确认名称，再返回可用价格信息",copy:"适合产品或服务询价。输入明确名称时，回复会更稳定；如果名称模糊，我会先帮你缩小范围。",bullets:["优先输入产品名","也可问咨询服务价格","若资料缺失，我会提醒转人工确认"]},contact:{title:"进入人工沟通前，把关键信息一次说清",copy:"适合准备推进合作时使用。你可以先拿联系方式，也可以直接提交表单，减少来回补充。",bullets:["可先拿电话和邮箱","可提交公司和需求","适合报价、合作或项目咨询"]}},x=s.load();function b(){s.save(x)}async function O(a,p,g){return(await Pe({endpoint:n.llmEndpoint,apiKey:n.apiKey,model:n.model,fetcher:n.fetcher,systemPrompt:n.systemPrompt||"你是制造业网站的 AI 客服。你需要保持专业、可信、主动推进成交，并在合适时收集线索。",soulProfile:n.soulProfile||{role:"制造业解决方案顾问",tone:"专业、直接、可信、有销售推进意识",goals:["快速判断用户意图","推动咨询或留资","回答时保持品牌人格"]},fallback:async()=>g()}).reply({message:p,history:x[a].filter(m=>m.content.trim()).slice(-6).map(m=>({role:m.role,content:m.content})),context:d?[`站点：${d.siteConfig.brandName}`,`简介：${d.siteConfig.about}`,`产品数：${d.products.length}`,`咨询服务数：${d.consultingServices.length}`].join(`
`):""})).content}function c(){return e?.querySelector(".cbot-panel")??null}function w(){if(l)return{brandName:l.brandName,heroTitle:B.heroTitle,about:B.about,phone:l.contactPhone,email:l.contactEmail,address:l.contactAddress};const a=n.contact||{};return{...B,...a,brandName:n.siteName||a.brandName||B.brandName}}function N(){return n.fetcher||fetch}async function _(){if(!n.tenantId)return;const a=await N()(`${R("/api/embed/config",n.apiBaseUrl)}?tenantId=${encodeURIComponent(n.tenantId)}`);if(!a.ok)throw new Error("Failed to load tenant config");l=await a.json()}function U(){if(!e||!l)return;const a=e.querySelector(".cbot-kicker");a&&(a.textContent=l.brandName);const p=e.querySelector(".cbot-contact-meta");p&&(p.textContent=`电话：${l.contactPhone}
邮箱：${l.contactEmail}
地址：${l.contactAddress}`)}async function G(a,p=[]){if(!n.tenantId)throw new Error("tenantId is required");const g=await N()(R("/api/chat",n.apiBaseUrl),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tenantId:n.tenantId,sessionId:i,message:a,attachments:p})});if(!g.ok)throw new Error("Failed to send chat message");const f=await g.json();return i=f.sessionId||i,f.reply}async function V(a){if(!n.tenantId)throw new Error("tenantId is required");const p=await N()(R("/api/contact",n.apiBaseUrl),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...a,tenantId:n.tenantId,sessionId:i})});if(!p.ok)throw new Error("Failed to submit lead");return(await p.json()).message||"提交成功，我们会尽快联系你。"}function X(){const a=e?.querySelector(".cbot-templates");a&&(a.innerHTML=E[o].map(p=>`<button type="button" class="cbot-template-btn" data-prompt="${p.prompt}">${p.label}</button>`).join(""))}function I(a="",p="default"){const g=e?.querySelector(".cbot-chat-status");g&&(g.textContent=a,g.classList.toggle("is-error",p==="error"))}function Z(){const a=e?.querySelector(".cbot-context-copy");a&&(a.textContent=z[o])}function ee(){if(!e?.querySelector(".cbot-chat-log")||x[o].length>0)return"";const p=j[o];return`
      <section class="cbot-welcome">
        <p class="cbot-welcome-title">${p.title}</p>
        <p class="cbot-welcome-copy">${p.copy}</p>
        <ul class="cbot-welcome-list">
          ${p.bullets.map((g,f)=>`<li class="cbot-welcome-item"><span class="cbot-welcome-dot">${f+1}</span><span>${g}</span></li>`).join("")}
        </ul>
      </section>
    `}function te(a){const p=a.split(/\n{2,}/).map(g=>g.trim()).filter(Boolean);return p.length?`<div class="cbot-message-body">${p.map(g=>`<p class="cbot-message-paragraph">${g.replace(/\n/g,"<br />")}</p>`).join("")}</div>`:'<p class="cbot-message-paragraph"></p>'}function F(a){r=a;const p=e?.querySelector(".cbot-send"),g=e?.querySelector(".cbot-input"),f=e?.querySelector(".cbot-file-input");p&&(p.disabled=a,p.textContent=a?"发送中...":"发送"),g&&(g.disabled=a),f&&(f.disabled=a),a&&I("AI 正在处理你的问题...","default")}function W(){const a=e?.querySelector(".cbot-chat-log");if(!a)return;const p=x[o].map(g=>g).reduce((g,f,v)=>{if(v===0){const m=ee();m&&g.push(m)}return g.push(`
          <div class="cbot-message-row ${f.role==="user"?"is-user":f.role==="system"?"is-system":""}">
            <span class="cbot-message-avatar">${f.role==="user"?"我":f.role==="system"?"!":"AI"}</span>
            <div class="cbot-message-bubble">
              <article class="cbot-message ${f.role==="user"?"is-user":f.role==="system"?"is-system":""}">
                <p class="cbot-message-meta">${f.role==="user"?"你":f.role==="system"?"系统提示":"AI 客服"}</p>
                ${te(f.content)}
                ${f.attachments?.length?`<div class="cbot-message-attachments">${f.attachments.map(m=>`<a class="cbot-message-attachment" href="${m.dataUrl}" target="_blank" rel="noreferrer"><img src="${m.dataUrl}" alt="${m.name}" /></a>`).join("")}</div>`:""}
              </article>
              <div class="cbot-message-note">${f.role==="user"?"已发送":f.role==="system"?"请处理后重试":"基于当前资料整理回复"}</div>
            </div>
          </div>
        `),g},[]).join("");a.innerHTML=`<div class="cbot-chat-stack">${p}</div>`,a.scrollTop=a.scrollHeight}function oe(){e?.querySelector(".cbot-contact-panel")?.classList.toggle("is-active",o==="contact"),Z(),X(),W()}function A(a,p,g,f){x[a].push({id:`${a}-${Date.now()}-${x[a].length+1}`,role:p,content:g,createdAt:Date.now(),attachments:f?.length?structuredClone(f):void 0}),b(),W()}function q(){const a=e?.querySelector(".cbot-attachment-list");a&&(a.innerHTML=u.map(p=>`<span class="cbot-attachment-chip">${p.name}<button type="button" data-remove-attachment="${p.id}">移除</button></span>`).join(""))}function ne(a){u=u.filter(p=>p.id!==a),q()}async function re(a){const p=Array.from(a||[]).filter(g=>g.type.startsWith("image/"));return Promise.all(p.map(g=>new Promise((f,v)=>{const m=new FileReader;m.onload=()=>{f({id:`attachment-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,name:g.name,mimeType:g.type||"image/png",size:g.size,dataUrl:String(m.result||"")})},m.onerror=()=>{v(m.error||new Error("Failed to read file"))},m.readAsDataURL(g)})))}function ae(a){if(x[a].length>0)return;A(a,"assistant",{md:"可以直接开始提问。我会优先根据当前站点资料，整理成更容易阅读的结构化答复。",price:"可以直接输入产品或咨询服务名称。我会尽量返回命中的价格信息，并提醒是否需要人工继续确认。",contact:"可以先拿联系方式，也可以直接提交合作需求。我会引导你把必要信息一次补齐。"}[a])}function se(){const a=e?.querySelector(".cbot-trigger"),p=e?.querySelector(".cbot-close"),g=e?.querySelector(".cbot-templates"),f=e?.querySelector(".cbot-chat-form"),v=e?.querySelector(".cbot-input"),m=e?.querySelector(".cbot-file-input"),T=e?.querySelector(".cbot-contact-form");a?.addEventListener("click",()=>{H.open()}),p?.addEventListener("click",()=>{H.close()}),g?.addEventListener("click",$=>{const h=$.target;!h.classList.contains("cbot-template-btn")||!v||(v.value=h.dataset.prompt||"",f?.requestSubmit())}),e?.addEventListener("click",$=>{const y=$.target?.getAttribute("data-remove-attachment");y&&ne(y)}),m?.addEventListener("change",async()=>{if(!r)try{const $=await re(m.files);u=[...u,...$].slice(0,4),q()}finally{m.value=""}}),f?.addEventListener("submit",async $=>{if($.preventDefault(),!v||!d||r)return;const h=v.value.trim();if(!h)return;const y=u;u=[],q(),A(o,"user",h,y),v.value="",F(!0);try{if(n.tenantId){const k=await G(h,y);A(o,"assistant",k),I("");return}if(o==="md"){const k=await O(o,h,()=>Ee({query:h,knowledgeEntries:d.knowledge,articles:d.articles,products:d.products,consultingServices:d.consultingServices,contentSources:[],siteConfig:d.siteConfig,attachments:y}));A(o,"assistant",k),I("");return}A(o,"assistant",`可以直接联系我：
- 电话：${d.siteConfig.phone}
- 邮箱：${d.siteConfig.email}
- 地址：${d.siteConfig.address}
你也可以使用下方表单提交需求。`),I("")}catch(k){const M=k instanceof Error?k.message:"发送失败，请稍后重试。";A(o,"system",`当前消息发送失败。
${M}`),I("当前消息发送失败，请检查机器人服务或稍后重试。","error")}finally{F(!1)}}),T?.addEventListener("submit",async $=>{if($.preventDefault(),!d)return;const h=e?.querySelector(".cbot-contact-notice"),y=new FormData(T),k={name:String(y.get("name")||""),company:String(y.get("company")||""),contact:String(y.get("contact")||""),demandType:String(y.get("demandType")||""),message:String(y.get("message")||"")};if(n.tenantId){try{const M=await V(k);h&&(h.textContent=M),T.reset()}catch{h&&(h.textContent="提交失败，请稍后再试。")}return}if(n.submitEndpoint){try{const ce=await(await fetch(n.submitEndpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(k)})).json();h&&(h.textContent=ce.message||"提交成功，我们会尽快联系你。"),T.reset()}catch{h&&(h.textContent="提交失败，请稍后再试。")}return}h&&(h.textContent="提交成功，我们会在 1 个工作日内联系你。"),T.reset()})}const H={init(a={}){if(e||t)return;if(n=a,n.mode==="iframe"){t=Le(),t.mount({iframeSrc:n.iframeSrc||"./customer-bot-frame.html"});return}d={knowledge:n.knowledge||de,articles:n.articles||pe,products:n.products||le,consultingServices:n.consultingServices||ie,siteConfig:w()},e=Be(n.themeColor||"#118ab2",n.siteName||d.siteConfig.brandName),se(),U(),q(),I("");const p=e.querySelector(".cbot-contact-meta");p&&!l&&(p.textContent=`电话：${d.siteConfig.phone}
邮箱：${d.siteConfig.email}
地址：${d.siteConfig.address}`),ae(o),oe(),n.tenantId&&_().then(()=>{d=d&&{...d,siteConfig:w()},U()})},open(){t||c()?.classList.add("is-open")},close(){t||c()?.classList.remove("is-open")},destroy(){t?.destroy(),t=null,u=[],e?.remove(),e=null}};return H}export{Ne as createCustomerBot};
