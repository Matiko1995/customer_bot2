import{b as u}from"./CPd5p-TQ.js";import"./DqYdt1bP.js";function s(){async function r(t,e){return $fetch(t,{credentials:"include",headers:u(e?.headers),...e})}return{request:r}}export{s as u};
