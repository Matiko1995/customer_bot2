import { g as getStorage } from './index.mjs';

async function resolveTenant(identifier, storage = getStorage()) {
  const normalized = identifier.trim();
  if (!normalized) {
    return void 0;
  }
  const byId = await storage.getTenantById(normalized);
  if (byId && !byId.deletedAt) {
    return byId;
  }
  const byEmbedKey = await storage.getTenantByEmbedKey(normalized);
  if (byEmbedKey && !byEmbedKey.deletedAt) {
    return byEmbedKey;
  }
  return void 0;
}

export { resolveTenant as r };
//# sourceMappingURL=tenant-resolver.mjs.map
