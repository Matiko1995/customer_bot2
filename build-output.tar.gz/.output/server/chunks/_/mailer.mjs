import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';

function getMailOutboxPath() {
  return process.env.CUSTOMER_BOT_MAIL_OUTBOX_FILE || resolve(process.cwd(), ".data/customer-bot-mail-outbox.json");
}
function getBaseUrl() {
  return (process.env.CUSTOMER_BOT_PUBLIC_BASE_URL || process.env.CUSTOMER_BOT_STAGING_BASE_URL || "https://bot.aifactory.website").replace(/\/+$/, "");
}
function createTenantResetEmailPayload(input) {
  const expiresAt = new Date(input.expiresAt).toLocaleString();
  const subject = `\u3010${input.tenantName}\u3011\u79DF\u6237\u540E\u53F0\u91CD\u7F6E\u7801`;
  const text = `\u79DF\u6237\uFF1A${input.tenantName}
\u4F60\u7684\u79DF\u6237\u540E\u53F0\u91CD\u7F6E\u7801\u662F\uFF1A${input.code}
\u6709\u6548\u671F\u81F3\uFF1A${expiresAt}
\u767B\u5F55\u5730\u5740\uFF1A${input.loginUrl}
\u5982\u679C\u8FD9\u4E0D\u662F\u4F60\u7684\u64CD\u4F5C\uFF0C\u8BF7\u5FFD\u7565\u672C\u90AE\u4EF6\u3002`;
  const html = `<p>\u79DF\u6237\uFF1A<strong>${input.tenantName}</strong></p><p>\u4F60\u7684\u79DF\u6237\u540E\u53F0\u91CD\u7F6E\u7801\u662F\uFF1A<strong>${input.code}</strong></p><p>\u6709\u6548\u671F\u81F3\uFF1A${expiresAt}</p><p>\u767B\u5F55\u5730\u5740\uFF1A<a href="${input.loginUrl}">${input.loginUrl}</a></p><p>\u5982\u679C\u8FD9\u4E0D\u662F\u4F60\u7684\u64CD\u4F5C\uFF0C\u8BF7\u5FFD\u7565\u672C\u90AE\u4EF6\u3002</p>`;
  return {
    to: input.to,
    subject,
    text,
    html
  };
}
async function appendMailOutbox(filePath, record) {
  let items = [];
  try {
    const raw = await readFile(filePath, "utf8");
    const parsed = JSON.parse(raw);
    items = Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    const maybe = error;
    if ((maybe == null ? void 0 : maybe.code) !== "ENOENT") {
      throw error;
    }
  }
  items.push(record);
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, JSON.stringify(items, null, 2), "utf8");
}
async function sendByResend(payload) {
  var _a, _b;
  const apiKey = (_a = process.env.CUSTOMER_BOT_RESEND_API_KEY) == null ? void 0 : _a.trim();
  const from = (_b = process.env.CUSTOMER_BOT_MAIL_FROM) == null ? void 0 : _b.trim();
  if (!apiKey || !from) {
    throw new Error("Resend mail is not configured");
  }
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from,
      to: [payload.to],
      subject: payload.subject,
      html: payload.html,
      text: payload.text
    })
  });
  if (!response.ok) {
    throw new Error(`Resend send failed: ${response.status}`);
  }
}
async function sendTenantResetEmail(input) {
  var _a;
  const payload = createTenantResetEmailPayload({
    ...input,
    loginUrl: input.loginUrl || `${getBaseUrl()}/tenant/login`
  });
  const provider = (_a = process.env.CUSTOMER_BOT_MAIL_PROVIDER) == null ? void 0 : _a.trim().toLowerCase();
  const createdAt = Date.now();
  if (provider === "resend") {
    await sendByResend(payload);
    return {
      delivered: true,
      provider: "resend",
      previewCode: ""
    };
  }
  await appendMailOutbox(getMailOutboxPath(), {
    ...payload,
    provider: "outbox",
    createdAt
  });
  return {
    delivered: false,
    provider: "outbox",
    previewCode: input.code
  };
}

export { sendTenantResetEmail as s };
//# sourceMappingURL=mailer.mjs.map
