const billingPlans = [
  {
    id: "plan-basic",
    name: "\u57FA\u7840\u7248",
    monthlyFee: "99.00",
    includedTokens: 5e4,
    overagePricePerThousandTokens: "1.00",
    active: true
  },
  {
    id: "plan-standard",
    name: "\u6807\u51C6\u7248",
    monthlyFee: "199.00",
    includedTokens: 1e5,
    overagePricePerThousandTokens: "0.80",
    active: true
  },
  {
    id: "plan-pro",
    name: "\u4E13\u4E1A\u7248",
    monthlyFee: "399.00",
    includedTokens: 25e4,
    overagePricePerThousandTokens: "0.60",
    active: true
  }
];
function getBillingPlanById(planId) {
  var _a;
  if (!planId) {
    return null;
  }
  return (_a = billingPlans.find((item) => item.id === planId)) != null ? _a : null;
}

export { getBillingPlanById as g };
//# sourceMappingURL=billing-plans.mjs.map
