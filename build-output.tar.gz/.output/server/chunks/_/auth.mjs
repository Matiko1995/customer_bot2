import { b as getCookie, c as createError, e as setCookie, f as deleteCookie } from '../nitro/nitro.mjs';

const ADMIN_COOKIE = "customer_bot_admin";
const TENANT_COOKIE = "customer_bot_tenant";
function getAdminConfig() {
  return {
    email: process.env.CUSTOMER_BOT_ADMIN_EMAIL || "admin@example.com",
    password: process.env.CUSTOMER_BOT_ADMIN_PASSWORD || "admin123456"
  };
}
function validateAdminCredentials(email, password) {
  const config = getAdminConfig();
  return email === config.email && password === config.password;
}
function setAdminSession(event) {
  setCookie(event, ADMIN_COOKIE, "authenticated", {
    httpOnly: true,
    sameSite: "lax",
    path: "/"
  });
}
function requireAdminSession(event) {
  const session = getCookie(event, ADMIN_COOKIE);
  if (session !== "authenticated") {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
}
function setTenantSession(event, payload) {
  setCookie(event, TENANT_COOKIE, JSON.stringify(payload), {
    httpOnly: true,
    sameSite: "lax",
    path: "/"
  });
}
function clearTenantSession(event) {
  deleteCookie(event, TENANT_COOKIE, {
    path: "/"
  });
}
function requireTenantSession(event) {
  const raw = getCookie(event, TENANT_COOKIE);
  if (!raw) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  try {
    const parsed = JSON.parse(raw);
    if (!parsed.tenantUserId || !parsed.tenantId || !parsed.email) {
      throw new Error("invalid tenant session");
    }
    return parsed;
  } catch {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
}

export { requireTenantSession as a, setTenantSession as b, clearTenantSession as c, requireAdminSession as r, setAdminSession as s, validateAdminCredentials as v };
//# sourceMappingURL=auth.mjs.map
