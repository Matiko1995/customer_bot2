import { resolve, dirname } from 'node:path';
import { readFile, mkdir, writeFile } from 'node:fs/promises';

const DEMO_TENANT_ID = "tenant-demo";

function getStorageFilePath() {
  return process.env.CUSTOMER_BOT_DATA_FILE || resolve(process.cwd(), ".data/customer-bot-storage.json");
}
function createDemoTenant() {
  const now = Date.now();
  return {
    id: DEMO_TENANT_ID,
    name: "Demo Tenant",
    status: "active",
    brandName: "AIFactory Demo Bot",
    themeColor: "#118ab2",
    contactPhone: "+86 138-0000-0000",
    contactEmail: "demo@example.com",
    contactAddress: "Shanghai",
    systemPrompt: "\u4F60\u662F AIFactory \u7684 AI \u5BA2\u670D\u6F14\u793A\u52A9\u624B\u3002\u8BF7\u4F18\u5148\u56DE\u7B54\u4EA7\u54C1\u80FD\u529B\u3001\u90E8\u7F72\u65B9\u5F0F\u3001\u62A5\u4EF7\u6D41\u7A0B\uFF0C\u5E76\u4E3B\u52A8\u5F15\u5BFC\u7528\u6237\u7559\u8D44\u3002",
    embedKey: "embed-demo-tenant",
    billingSubscription: {
      planId: "plan-standard",
      startedAt: now,
      notes: "demo tenant default plan"
    },
    contentConfig: void 0,
    createdAt: now,
    updatedAt: now
  };
}

const cloneRecord = (value) => structuredClone(value);
const createEmptyState = () => ({
  tenants: [],
  sessions: [],
  messages: [],
  leads: [],
  usage: [],
  tenantUsers: [],
  tenantPasswordResets: []
});
const createFileStore = (options) => {
  let statePromise;
  let writeQueue = Promise.resolve();
  async function persist(state) {
    const nextState = cloneRecord(state);
    writeQueue = writeQueue.then(async () => {
      await mkdir(dirname(options.filePath), { recursive: true });
      await writeFile(options.filePath, JSON.stringify(nextState, null, 2), "utf8");
    });
    await writeQueue;
  }
  async function loadState() {
    try {
      const raw = await readFile(options.filePath, "utf8");
      const parsed = JSON.parse(raw);
      return {
        tenants: Array.isArray(parsed.tenants) ? parsed.tenants.map(cloneRecord) : [],
        sessions: Array.isArray(parsed.sessions) ? parsed.sessions.map(cloneRecord) : [],
        messages: Array.isArray(parsed.messages) ? parsed.messages.map(cloneRecord) : [],
        leads: Array.isArray(parsed.leads) ? parsed.leads.map(cloneRecord) : [],
        usage: Array.isArray(parsed.usage) ? parsed.usage.map(cloneRecord) : [],
        tenantUsers: Array.isArray(parsed.tenantUsers) ? parsed.tenantUsers.map(cloneRecord) : [],
        tenantPasswordResets: Array.isArray(parsed.tenantPasswordResets) ? parsed.tenantPasswordResets.map(cloneRecord) : []
      };
    } catch (error) {
      const maybeError = error;
      if ((maybeError == null ? void 0 : maybeError.code) !== "ENOENT") {
        throw error;
      }
      return createEmptyState();
    }
  }
  async function ensureState() {
    if (!statePromise) {
      statePromise = (async () => {
        var _a;
        const state = await loadState();
        const seedTenants = (_a = options.seedTenants) != null ? _a : [];
        let changed = false;
        for (const tenant of seedTenants) {
          if (!state.tenants.some((item) => item.id === tenant.id)) {
            state.tenants.push(cloneRecord(tenant));
            changed = true;
          }
        }
        if (changed) {
          await persist(state);
        }
        return state;
      })();
    }
    return statePromise;
  }
  async function updateState(mutator) {
    const state = await ensureState();
    await mutator(state);
    await persist(state);
  }
  return {
    async saveTenant(tenant) {
      await updateState((state) => {
        const nextTenant = cloneRecord(tenant);
        const index = state.tenants.findIndex((item) => item.id === tenant.id);
        if (index >= 0) {
          state.tenants[index] = nextTenant;
          return;
        }
        state.tenants.push(nextTenant);
      });
    },
    async getTenantById(tenantId) {
      const state = await ensureState();
      const tenant = state.tenants.find((item) => item.id === tenantId);
      return tenant ? cloneRecord(tenant) : void 0;
    },
    async getTenantByEmbedKey(embedKey) {
      const state = await ensureState();
      const tenant = state.tenants.find((item) => item.embedKey === embedKey);
      return tenant ? cloneRecord(tenant) : void 0;
    },
    async listTenants() {
      const state = await ensureState();
      return state.tenants.map(cloneRecord);
    },
    async saveSession(session) {
      await updateState((state) => {
        const nextSession = cloneRecord(session);
        const index = state.sessions.findIndex((item) => item.id === session.id);
        if (index >= 0) {
          state.sessions[index] = nextSession;
          return;
        }
        state.sessions.push(nextSession);
      });
    },
    async getSessionById(sessionId) {
      const state = await ensureState();
      const session = state.sessions.find((item) => item.id === sessionId);
      return session ? cloneRecord(session) : void 0;
    },
    async listSessionsByTenant(tenantId) {
      const state = await ensureState();
      return state.sessions.filter((item) => item.tenantId === tenantId).map(cloneRecord);
    },
    async saveMessage(message) {
      await updateState((state) => {
        state.messages.push(cloneRecord(message));
      });
    },
    async listMessagesBySession(sessionId) {
      const state = await ensureState();
      return state.messages.filter((item) => item.sessionId === sessionId).map(cloneRecord);
    },
    async saveLead(lead) {
      await updateState((state) => {
        state.leads.push(cloneRecord(lead));
      });
    },
    async listLeadsByTenant(tenantId) {
      const state = await ensureState();
      return state.leads.filter((item) => item.tenantId === tenantId).map(cloneRecord);
    },
    async saveUsageRecord(record) {
      await updateState((state) => {
        state.usage.push(cloneRecord(record));
      });
    },
    async listUsageByTenant(tenantId) {
      const state = await ensureState();
      return state.usage.filter((item) => item.tenantId === tenantId).map(cloneRecord);
    },
    async saveTenantUser(user) {
      await updateState((state) => {
        const nextUser = cloneRecord(user);
        const index = state.tenantUsers.findIndex((item) => item.id === user.id);
        if (index >= 0) {
          state.tenantUsers[index] = nextUser;
          return;
        }
        state.tenantUsers.push(nextUser);
      });
    },
    async getTenantUserByEmail(email) {
      const state = await ensureState();
      const normalized = email.trim().toLowerCase();
      const user = state.tenantUsers.find((item) => item.email.toLowerCase() === normalized);
      return user ? cloneRecord(user) : void 0;
    },
    async getTenantUserById(userId) {
      const state = await ensureState();
      const user = state.tenantUsers.find((item) => item.id === userId);
      return user ? cloneRecord(user) : void 0;
    },
    async listTenantUsersByTenant(tenantId) {
      const state = await ensureState();
      return state.tenantUsers.filter((item) => item.tenantId === tenantId).map(cloneRecord);
    },
    async saveTenantPasswordReset(record) {
      await updateState((state) => {
        const nextRecord = cloneRecord(record);
        const index = state.tenantPasswordResets.findIndex((item) => item.id === record.id);
        if (index >= 0) {
          state.tenantPasswordResets[index] = nextRecord;
          return;
        }
        state.tenantPasswordResets.push(nextRecord);
      });
    },
    async getTenantPasswordResetByCode(email, code) {
      const state = await ensureState();
      const normalized = email.trim().toLowerCase();
      const item = state.tenantPasswordResets.find((reset) => reset.email.toLowerCase() === normalized && reset.code === code);
      return item ? cloneRecord(item) : void 0;
    }
  };
};

let singletonStore;
const createStorage = () => createFileStore({
  filePath: getStorageFilePath(),
  seedTenants: [createDemoTenant()]
});
const getStorage = () => {
  if (!singletonStore) {
    singletonStore = createStorage();
  }
  return singletonStore;
};

export { getStorage as g };
//# sourceMappingURL=index.mjs.map
