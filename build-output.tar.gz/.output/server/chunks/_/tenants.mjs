import { g as getStorage } from './index.mjs';
import { r as resolveTenant } from './tenant-resolver.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
class TenantNotFoundError extends Error {
  constructor(tenantId) {
    super(`Tenant not found: ${tenantId}`);
    __publicField(this, "code", "TENANT_NOT_FOUND");
    this.name = "TenantNotFoundError";
    Object.setPrototypeOf(this, TenantNotFoundError.prototype);
  }
}
async function getRuntimeConfigForTenant(tenantId, storage = getStorage()) {
  const tenant = await resolveTenant(tenantId, storage);
  if (!tenant) {
    throw new TenantNotFoundError(tenantId);
  }
  return {
    tenantId: tenant.id,
    status: tenant.status,
    brandName: tenant.brandName,
    themeColor: tenant.themeColor,
    contactPhone: tenant.contactPhone,
    contactEmail: tenant.contactEmail,
    contactAddress: tenant.contactAddress,
    systemPrompt: tenant.systemPrompt
  };
}

export { TenantNotFoundError as T, getRuntimeConfigForTenant as g };
//# sourceMappingURL=tenants.mjs.map
