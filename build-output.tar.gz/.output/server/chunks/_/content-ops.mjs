function aggregateMatchedContentSourceStats(messages) {
  var _a;
  const grouped = /* @__PURE__ */ new Map();
  for (const message of messages) {
    for (const source of (_a = message.matchedContentSources) != null ? _a : []) {
      const existing = grouped.get(source.id);
      if (existing) {
        existing.hits += 1;
        continue;
      }
      grouped.set(source.id, {
        ...source,
        hits: 1
      });
    }
  }
  return Array.from(grouped.values()).sort((left, right) => right.hits - left.hits || left.title.localeCompare(right.title, "zh-CN"));
}

export { aggregateMatchedContentSourceStats as a };
//# sourceMappingURL=content-ops.mjs.map
