const TRAINING_PROVIDER = "training-simulator";
function listTrainingRuns(records) {
  return records.filter((item) => item.provider === TRAINING_PROVIDER).sort((left, right) => right.createdAt - left.createdAt).map((item) => ({
    id: item.id,
    sessionId: item.sessionId,
    provider: item.provider,
    model: item.model,
    inputTokens: item.inputTokens,
    outputTokens: item.outputTokens,
    totalTokens: item.totalTokens,
    amount: item.amount,
    status: item.status,
    createdAt: item.createdAt
  }));
}

export { TRAINING_PROVIDER as T, listTrainingRuns as l };
//# sourceMappingURL=training-runs.mjs.map
