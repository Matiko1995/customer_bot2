function getMonthKey(timestamp) {
  const date = new Date(timestamp);
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  return `${year}-${month}`;
}
function addMoney(left, right) {
  return (Number(left) + Number(right)).toFixed(2);
}
function multiplyMoney(left, right) {
  return (Number(left) * right).toFixed(2);
}
function buildMonthlyBillingSummary(records, plan, subscription) {
  const grouped = /* @__PURE__ */ new Map();
  for (const record of records) {
    if (record.status !== "success") {
      continue;
    }
    const month = getMonthKey(record.createdAt);
    const key = `${record.tenantId}:${month}`;
    const existing = grouped.get(key);
    if (existing) {
      existing.inputTokens += record.inputTokens;
      existing.outputTokens += record.outputTokens;
      existing.totalTokens += record.totalTokens;
      if (!plan || !subscription) {
        existing.amount = addMoney(existing.amount, record.amount);
      }
      continue;
    }
    grouped.set(key, {
      tenantId: record.tenantId,
      month,
      inputTokens: record.inputTokens,
      outputTokens: record.outputTokens,
      totalTokens: record.totalTokens,
      includedTokens: 0,
      billableTokens: 0,
      baseFee: "0.00",
      overageFee: "0.00",
      amount: !plan || !subscription ? Number(record.amount).toFixed(2) : "0.00"
    });
  }
  for (const summary of grouped.values()) {
    if (!plan || !subscription) {
      continue;
    }
    summary.includedTokens = plan.includedTokens;
    summary.billableTokens = Math.max(0, summary.totalTokens - plan.includedTokens);
    summary.baseFee = Number(plan.monthlyFee).toFixed(2);
    summary.overageFee = multiplyMoney(plan.overagePricePerThousandTokens, summary.billableTokens / 1e3);
    summary.amount = addMoney(summary.baseFee, summary.overageFee);
  }
  return Array.from(grouped.values()).sort((left, right) => left.month.localeCompare(right.month));
}
function buildBillingCsv(summaries) {
  const header = [
    "tenantId",
    "month",
    "inputTokens",
    "outputTokens",
    "totalTokens",
    "includedTokens",
    "billableTokens",
    "baseFee",
    "overageFee",
    "amount"
  ];
  const rows = summaries.map(
    (item) => [
      item.tenantId,
      item.month,
      item.inputTokens,
      item.outputTokens,
      item.totalTokens,
      item.includedTokens,
      item.billableTokens,
      item.baseFee,
      item.overageFee,
      item.amount
    ].join(",")
  );
  return [header.join(","), ...rows].join("\n");
}

export { buildBillingCsv as a, buildMonthlyBillingSummary as b };
//# sourceMappingURL=billing.mjs.map
