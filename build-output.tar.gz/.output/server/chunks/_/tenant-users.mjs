import { randomInt, createHash } from 'node:crypto';

function hashPassword(password) {
  return createHash("sha256").update(password).digest("hex");
}
function normalizeEmail(email) {
  return email.trim().toLowerCase();
}
function generateInitialPassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  let output = "";
  for (let index = 0; index < 10; index += 1) {
    output += chars[randomInt(0, chars.length)];
  }
  return output;
}
function generateResetCode() {
  return String(randomInt(0, 1e6)).padStart(6, "0");
}
function buildFallbackEmail(tenant) {
  return `${tenant.id}@tenant.local`;
}
async function createTenantLoginForTenant(input) {
  var _a;
  const now = (_a = input.now) != null ? _a : Date.now();
  const email = normalizeEmail(input.tenant.contactEmail || buildFallbackEmail(input.tenant));
  const existing = await input.storage.getTenantUserByEmail(email);
  if (existing) {
    return {
      user: existing,
      initialPassword: existing.temporaryPassword || ""
    };
  }
  const initialPassword = generateInitialPassword();
  const user = {
    id: `tenant-user-${input.tenant.id}`,
    tenantId: input.tenant.id,
    email,
    passwordHash: hashPassword(initialPassword),
    temporaryPassword: initialPassword,
    mustChangePassword: true,
    status: "active",
    createdAt: now,
    updatedAt: now
  };
  await input.storage.saveTenantUser(user);
  return {
    user,
    initialPassword
  };
}
async function verifyTenantPassword(email, password, storage) {
  const user = await storage.getTenantUserByEmail(email);
  if (!user || user.status !== "active") {
    return null;
  }
  return user.passwordHash === hashPassword(password) ? user : null;
}
async function issueTenantPasswordReset(input) {
  var _a;
  const user = await input.storage.getTenantUserByEmail(input.email);
  if (!user) {
    throw new Error("\u79DF\u6237\u8D26\u53F7\u4E0D\u5B58\u5728");
  }
  const now = (_a = input.now) != null ? _a : Date.now();
  const record = {
    id: `tenant-reset-${user.id}-${now}`,
    tenantUserId: user.id,
    tenantId: user.tenantId,
    email: user.email,
    code: generateResetCode(),
    expiresAt: now + 15 * 60 * 1e3,
    usedAt: 0,
    createdAt: now
  };
  await input.storage.saveTenantPasswordReset(record);
  return record;
}
async function resetTenantPassword(input) {
  var _a;
  const normalizedEmail = normalizeEmail(input.email);
  const record = await input.storage.getTenantPasswordResetByCode(normalizedEmail, input.code.trim());
  const now = (_a = input.now) != null ? _a : Date.now();
  if (!record || record.usedAt || record.expiresAt < now) {
    throw new Error("\u9A8C\u8BC1\u7801\u65E0\u6548\u6216\u5DF2\u8FC7\u671F");
  }
  const user = await input.storage.getTenantUserById(record.tenantUserId);
  if (!user) {
    throw new Error("\u79DF\u6237\u8D26\u53F7\u4E0D\u5B58\u5728");
  }
  const updatedUser = {
    ...user,
    passwordHash: hashPassword(input.nextPassword),
    temporaryPassword: "",
    mustChangePassword: false,
    updatedAt: now
  };
  const updatedReset = {
    ...record,
    usedAt: now
  };
  await input.storage.saveTenantUser(updatedUser);
  await input.storage.saveTenantPasswordReset(updatedReset);
  return updatedUser;
}

export { createTenantLoginForTenant as c, issueTenantPasswordReset as i, resetTenantPassword as r, verifyTenantPassword as v };
//# sourceMappingURL=tenant-users.mjs.map
