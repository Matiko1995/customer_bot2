function buildTenantChatItems(sessions, messagesBySession) {
  return [...sessions].sort((left, right) => right.lastMessageAt - left.lastMessageAt).map((session) => {
    var _a;
    return {
      session,
      messages: [...(_a = messagesBySession.get(session.id)) != null ? _a : []].sort((left, right) => left.createdAt - right.createdAt)
    };
  });
}
function sortTenantLeads(leads) {
  return [...leads].sort((left, right) => right.createdAt - left.createdAt);
}

export { buildTenantChatItems as b, sortTenantLeads as s };
//# sourceMappingURL=tenant-readonly.mjs.map
