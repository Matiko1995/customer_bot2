import { d as defineEventHandler, r as readBody, c as createError, u as useRuntimeConfig } from '../../nitro/nitro.mjs';
import { g as getStorage } from '../../_/index.mjs';
import { T as TenantNotFoundError } from '../../_/tenants.mjs';
import { r as resolveTenant } from '../../_/tenant-resolver.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const assistantKnowledgeEntries = [
  {
    id: "wms-rfid",
    title: "WMS + RFID \u667A\u80FD\u4ED3\u50A8",
    keywords: ["wms", "rfid", "\u4ED3\u50A8", "\u4ED3\u5E93", "\u5165\u5E93", "\u51FA\u5E93", "\u76D8\u70B9", "\u5E93\u4F4D", "\u6279\u6B21\u8FFD\u6EAF", "fifo", "\u4ED3\u50A8\u7BA1\u7406"],
    oneLiner: "WMS + RFID \u662F\u628A\u4ED3\u5E93\u7BA1\u7406\u7CFB\u7EDF\u4E0E\u5C04\u9891\u8BC6\u522B\u7ED3\u5408\uFF0C\u5B9E\u73B0\u5165\u5E93\u3001\u5B9A\u4F4D\u3001\u76D8\u70B9\u3001\u51FA\u5E93\u5168\u6D41\u7A0B\u81EA\u52A8\u5316\u3002",
    whatIs: "\u7CFB\u7EDF\u901A\u8FC7 RFID \u81EA\u52A8\u8BC6\u522B\u8D27\u7269\u4FE1\u606F\uFF0C\u5E76\u7531 WMS \u5728\u6BEB\u79D2\u7EA7\u505A\u5E93\u4F4D\u4E0E\u4F5C\u4E1A\u51B3\u7B56\uFF0C\u51CF\u5C11\u4EBA\u5DE5\u626B\u7801\u3001\u4EBA\u5DE5\u5206\u914D\u548C\u4EBA\u5DE5\u6838\u5BF9\u73AF\u8282\u3002",
    problems: [
      "\u5165\u5E93/\u51FA\u5E93\u6548\u7387\u4F4E\uFF0C\u4EBA\u5DE5\u626B\u7801\u6162\u4E14\u5BB9\u6613\u6F0F\u626B\u9519\u626B",
      "\u5E93\u4F4D\u5206\u914D\u4F9D\u8D56\u7ECF\u9A8C\uFF0C\u5229\u7528\u7387\u4E0D\u9AD8\u4E14\u8C03\u5EA6\u4E0D\u7A33\u5B9A",
      "\u76D8\u70B9\u5468\u671F\u957F\u3001\u505C\u5DE5\u6210\u672C\u9AD8\u3001\u8D26\u5B9E\u4E0D\u4E00\u81F4",
      "\u6279\u6B21\u8FFD\u6EAF\u6162\uFF0C\u5F02\u5E38\u5B9A\u4F4D\u548C\u53EC\u56DE\u54CD\u5E94\u6162"
    ],
    workflow: [
      "RFID \u8BFB\u53D6\uFF1A0.1 \u79D2\u5B8C\u6210\u8D27\u7269\u8BC6\u522B",
      "\u81EA\u52A8\u5206\u914D\u4ED3\u5E93\uFF1A\u6309\u5E93\u5B58\u6C34\u4F4D\u3001\u5468\u8F6C\u7387\u3001\u5E93\u4F4D\u5229\u7528\u7387\u5339\u914D\u6700\u4F18\u533A\u57DF",
      "\u5E93\u4F4D\u5B9A\u4F4D\uFF1A\u5B9A\u4F4D\u5230\u8D27\u67B6\u533A/\u5217/\u5C42\uFF0C\u652F\u6301\u7EC8\u7AEF\u5BFC\u822A",
      "\u5165\u5E93\u5355\u751F\u6210\uFF1A\u81EA\u52A8\u540C\u6B65 ERP/MES/TMS\uFF0C\u4FDD\u7559\u5B8C\u6574\u8FFD\u6EAF\u8BB0\u5F55"
    ],
    scenarios: ["\u6C7D\u8F66\u96F6\u90E8\u4EF6\u4ED3\uFF0CSKU \u591A\u4E14\u6279\u6B21\u590D\u6742", "\u7535\u5B50\u5143\u5668\u4EF6\u4ED3\uFF0C\u9700\u8981\u6279\u6B21\u7EA7\u8FFD\u6EAF", "\u6210\u54C1\u4ED3\uFF0C\u591A\u8BA2\u5355\u5E76\u884C\u4E14\u53D1\u8D27\u51C6\u786E\u7387\u8981\u6C42\u9AD8"],
    outcomes: ["\u51FA\u5165\u5E93\u6548\u7387\u63D0\u5347\u7EA6 80%", "\u5E93\u5B58\u51C6\u786E\u7387\u53EF\u8FBE 99.5%", "\u76D8\u70B9\u65F6\u95F4\u53EF\u4ECE\u5929\u7EA7\u7F29\u77ED\u5230\u5C0F\u65F6\u7EA7", "\u9519\u53D1\u6F0F\u53D1\u663E\u8457\u4E0B\u964D"],
    source: "migrated from ai-manufacturing-trade-site"
  },
  {
    id: "procurement-ai",
    title: "\u91C7\u8D2D AI \u52A9\u624B",
    keywords: ["\u91C7\u8D2D", "\u7F3A\u6599", "\u4F9B\u5E94\u5546", "\u8BE2\u4EF7", "\u8865\u8D27", "\u5728\u9014", "\u5B89\u5168\u5E93\u5B58", "procurement"],
    oneLiner: "\u91C7\u8D2D AI \u52A9\u624B\u7528\u4E8E\u56DE\u7B54\u201C\u4E70\u4EC0\u4E48\u3001\u4E70\u591A\u5C11\u3001\u5411\u8C01\u4E70\u201D\uFF0C\u628A\u7F3A\u6599\u8BC6\u522B\u548C\u4F9B\u5E94\u5546\u9009\u62E9\u81EA\u52A8\u5316\u3002",
    whatIs: "\u7CFB\u7EDF\u7ED3\u5408\u5E93\u5B58\u3001\u5728\u9014\u91CF\u548C\u751F\u4EA7\u8BA1\u5212\uFF0C\u81EA\u52A8\u751F\u6210\u91C7\u8D2D\u5EFA\u8BAE\u5E76\u56DE\u5199\u5230\u4E1A\u52A1\u7CFB\u7EDF\u3002",
    problems: ["\u7F3A\u6599\u53D1\u73B0\u6EDE\u540E", "\u8BE2\u4EF7\u94FE\u8DEF\u957F", "\u4F9B\u5E94\u5546\u9009\u62E9\u7F3A\u5C11\u91CF\u5316\u4F9D\u636E"],
    workflow: ["\u8BC6\u522B\u7F3A\u6599", "\u751F\u6210\u5EFA\u8BAE\u91C7\u8D2D\u91CF", "\u6BD4\u9009\u4F9B\u5E94\u5546", "\u56DE\u5199\u4E0E\u590D\u76D8"],
    scenarios: ["\u591A\u54C1\u7C7B\u539F\u6599\u91C7\u8D2D", "\u4EA4\u671F\u654F\u611F\u8BA2\u5355", "\u6210\u672C\u4E0E\u7A33\u5B9A\u6027\u540C\u65F6\u8981\u6C42\u9AD8\u7684\u5236\u9020\u573A\u666F"],
    outcomes: ["\u51CF\u5C11\u505C\u7EBF\u98CE\u9669", "\u7F29\u77ED\u91C7\u8D2D\u54CD\u5E94\u65F6\u95F4", "\u63D0\u9AD8\u91C7\u8D2D\u51B3\u7B56\u4E00\u81F4\u6027"],
    source: "migrated from ai-manufacturing-trade-site"
  },
  {
    id: "finance-ocr",
    title: "\u8D22\u7A0E OCR \u81EA\u52A8\u5316",
    keywords: ["\u8D22\u7A0E", "\u53D1\u7968", "ocr", "\u7968\u636E", "\u5408\u89C4", "\u62A5\u9500"],
    oneLiner: "\u8D22\u7A0E OCR \u628A\u7968\u636E\u8BC6\u522B\u3001\u67E5\u9A8C\u3001\u5F52\u6863\u505A\u6210\u81EA\u52A8\u5316\u95ED\u73AF\uFF0C\u964D\u4F4E\u4EBA\u5DE5\u5F55\u5165\u548C\u5408\u89C4\u98CE\u9669\u3002",
    whatIs: "\u7CFB\u7EDF\u81EA\u52A8\u63D0\u53D6\u7968\u636E\u5B57\u6BB5\u5E76\u505A\u89C4\u5219\u6821\u9A8C\uFF0C\u5F02\u5E38\u5B9E\u65F6\u9884\u8B66\uFF0C\u6240\u6709\u5904\u7406\u8FC7\u7A0B\u53EF\u8FFD\u6EAF\u3002",
    problems: ["\u4EBA\u5DE5\u5F55\u7968\u6162\u4E14\u6613\u9519", "\u7968\u636E\u6838\u9A8C\u8D1F\u62C5\u91CD", "\u5BA1\u8BA1\u8FFD\u6EAF\u6210\u672C\u9AD8"],
    workflow: ["\u7968\u636E\u91C7\u96C6", "OCR \u8BC6\u522B", "\u89C4\u5219\u6821\u9A8C", "\u7ED3\u679C\u5F52\u6863\u8FFD\u6EAF"],
    scenarios: ["\u6708\u5EA6\u96C6\u4E2D\u5F00\u7968", "\u591A\u4E3B\u4F53\u62A5\u9500", "\u8D22\u7A0E\u5408\u89C4\u68C0\u67E5"],
    outcomes: ["\u63D0\u5347\u5904\u7406\u901F\u5EA6", "\u51CF\u5C11\u9519\u5F55\u6F0F\u5F55", "\u63D0\u9AD8\u5BA1\u8BA1\u53EF\u8FFD\u6EAF\u6027"],
    source: "migrated from ai-manufacturing-trade-site"
  }
];

const demoSiteConfig = {
  brandName: "AI Factory Customer Bot Demo",
  heroTitle: "\u5236\u9020\u4E1A AI \u89E3\u51B3\u65B9\u6848\u4E0E\u4F9B\u5E94\u94FE\u670D\u52A1",
  about: "\u8FD9\u4E2A\u6F14\u793A\u7AD9\u70B9\u63D0\u4F9B\u667A\u80FD\u4ED3\u50A8\u3001\u91C7\u8D2D AI\u3001\u8D22\u7A0E\u81EA\u52A8\u5316\u548C\u9879\u76EE\u54A8\u8BE2\u80FD\u529B\u3002",
  phone: "+86 138-0000-0000",
  email: "hello@example.com",
  address: "Shanghai, China"
};
const demoArticles = [
  {
    id: "article-wms",
    title: "WMS \u4E0E RFID \u5982\u4F55\u6539\u5584\u4ED3\u50A8\u6267\u884C",
    summary: "\u4ECB\u7ECD\u5165\u5E93\u3001\u51FA\u5E93\u3001\u76D8\u70B9\u4E0E\u6279\u6B21\u8FFD\u6EAF\u7684\u81EA\u52A8\u5316\u6539\u9020\u601D\u8DEF\u3002",
    category: "\u4ED3\u50A8"
  },
  {
    id: "article-ai",
    title: "\u91C7\u8D2D AI \u52A9\u624B\u7684\u843D\u5730\u65B9\u5F0F",
    summary: "\u56F4\u7ED5\u7F3A\u6599\u8BC6\u522B\u3001\u4F9B\u5E94\u5546\u6BD4\u9009\u548C\u8865\u8D27\u5EFA\u8BAE\u6784\u5EFA\u81EA\u52A8\u5316\u95ED\u73AF\u3002",
    category: "\u91C7\u8D2D"
  }
];
const demoProducts = [
  {
    id: "product-bolt",
    name: "\u516D\u89D2\u5934\u87BA\u6813",
    category: "\u6807\u51C6\u4EF6",
    summary: "\u9002\u7528\u4E8E\u591A\u79CD\u5DE5\u4E1A\u88C5\u914D\u573A\u666F\u7684\u5E38\u7528\u7D27\u56FA\u4EF6\u3002",
    priceText: "\xA50.80 / \u4E2A",
    parameters: [
      { label: "\u89C4\u683C", value: "M8 x 30" },
      { label: "\u6750\u8D28", value: "8.8 \u7EA7\u78B3\u94A2" },
      { label: "\u8868\u9762\u5904\u7406", value: "\u9540\u950C" },
      { label: "\u8D77\u8BA2\u91CF", value: "5000 \u4E2A" }
    ]
  },
  {
    id: "product-screw-machine",
    name: "\u9AD8\u901F\u87BA\u4E1D\u673A",
    category: "\u8BBE\u5907",
    summary: "\u9002\u5408\u6D41\u6C34\u7EBF\u81EA\u52A8\u9501\u9644\u7684\u9AD8\u901F\u88C5\u914D\u8BBE\u5907\u3002",
    priceText: "\xA528,000 / \u53F0",
    parameters: [
      { label: "\u8282\u62CD", value: "\u6BCF\u5206\u949F 45-60 \u9897" },
      { label: "\u9002\u914D\u87BA\u4E1D", value: "M2-M6" },
      { label: "\u4F9B\u7535", value: "220V / 50Hz" },
      { label: "\u4EA4\u671F", value: "15 \u4E2A\u5DE5\u4F5C\u65E5" }
    ]
  }
];
const demoConsultingServices = [
  {
    id: "consulting-diagnosis",
    name: "\u667A\u80FD\u5DE5\u5382\u8BCA\u65AD\u54A8\u8BE2",
    category: "\u54A8\u8BE2",
    introduction: "\u68B3\u7406\u73B0\u72B6\u3001\u8BC6\u522B\u74F6\u9888\u5E76\u8F93\u51FA\u8DEF\u7EBF\u56FE\u3002",
    price: "6800",
    negotiable: false
  },
  {
    id: "consulting-qc",
    name: "AI \u8D28\u68C0\u65B9\u6848\u54A8\u8BE2",
    category: "\u54A8\u8BE2",
    introduction: "\u56F4\u7ED5\u89C6\u89C9\u68C0\u6D4B\u4E0E\u8D28\u63A7\u6D41\u7A0B\u63D0\u4F9B\u65B9\u6848\u8BBE\u8BA1\u3002",
    price: "",
    negotiable: true
  }
];

function normalizeText(value) {
  return Array.from(value.toLowerCase()).filter((char) => /[a-z0-9\u4e00-\u9fa5]/.test(char)).join("");
}
function extractKeywords(value) {
  var _a;
  const words = value.toLowerCase().split(/[^a-z0-9\u4e00-\u9fa5]+/).map((word) => word.trim()).filter((word) => word.length >= 2);
  const chineseSegments = (_a = value.match(/[\u4e00-\u9fa5]{2,}/g)) != null ? _a : [];
  const chineseTokens = [];
  for (const segment of chineseSegments) {
    if (segment.length <= 4) {
      chineseTokens.push(segment);
      continue;
    }
    for (let index = 0; index < segment.length - 1; index += 1) {
      chineseTokens.push(segment.slice(index, index + 2));
    }
  }
  return Array.from(/* @__PURE__ */ new Set([...words, ...chineseTokens])).filter((word) => word.length >= 2);
}
function scoreSource(source, query, keywords) {
  const normalizedSource = normalizeText(source);
  if (!normalizedSource) {
    return 0;
  }
  let score = 0;
  const normalizedQuery = normalizeText(query);
  if (normalizedQuery && normalizedSource.includes(normalizedQuery)) {
    score += 10;
  }
  for (const keyword of keywords) {
    const normalizedKeyword = normalizeText(keyword);
    if (normalizedKeyword && normalizedSource.includes(normalizedKeyword)) {
      score += 2;
    }
  }
  return score;
}
function rankByQuery(items, query, resolveText) {
  const keywords = extractKeywords(query);
  return [...items].map((item) => ({
    item,
    score: scoreSource(resolveText(item), query, keywords)
  })).filter((item) => item.score > 0).sort((left, right) => right.score - left.score).map((item) => item.item);
}
function formatContentSourceType(type) {
  if (type === "webpage") return "\u7F51\u9875";
  if (type === "email") return "\u90AE\u4EF6";
  if (type === "excel") return "\u8868\u683C";
  return "\u6587\u6863";
}
function buildContentSourceCorpus(item) {
  var _a, _b, _c;
  return [
    item.title,
    item.category,
    item.summary,
    item.content,
    item.sourceLabel,
    item.sourceUrl,
    ...(_a = item.tags) != null ? _a : [],
    ...(_b = item.faqQuestions) != null ? _b : [],
    ...(_c = item.answerHints) != null ? _c : []
  ].filter(Boolean).join(" ");
}
function getEnabledContentSources(items) {
  return items.filter((item) => item.enabled !== false);
}
function splitContentIntoSegments(content) {
  const compact = content.replace(/\r/g, "\n").trim();
  if (!compact) {
    return [];
  }
  const paragraphSegments = compact.split(/\n{2,}/).map((segment) => segment.replace(/\s+/g, " ").trim()).filter(Boolean);
  const rawSegments = paragraphSegments.length ? paragraphSegments : compact.split(/[。！？!?；;\n]+/).map((segment) => segment.replace(/\s+/g, " ").trim());
  const limitedSegments = [];
  for (const segment of rawSegments.filter(Boolean)) {
    if (segment.length <= 140) {
      limitedSegments.push(segment);
      continue;
    }
    for (let index = 0; index < segment.length; index += 120) {
      const slice = segment.slice(index, index + 120).trim();
      if (slice) {
        limitedSegments.push(slice);
      }
    }
  }
  return limitedSegments.slice(0, 24);
}
function pickBestContentSegment(item, query) {
  var _a;
  const segments = splitContentIntoSegments(item.content);
  if (!segments.length) {
    return item.summary.trim();
  }
  const keywords = extractKeywords(query);
  const rankedSegments = segments.map((segment) => ({
    segment,
    score: scoreSource(segment, query, keywords)
  })).sort((left, right) => right.score - left.score);
  return ((_a = rankedSegments[0]) == null ? void 0 : _a.score) ? rankedSegments[0].segment : segments[0];
}
function pickMatchedContentSources(query, contentSources) {
  const keywords = extractKeywords(query);
  return [...getEnabledContentSources(contentSources)].map((item) => {
    var _a, _b;
    const corpusScore = scoreSource(buildContentSourceCorpus(item), query, keywords);
    const segmentScore = splitContentIntoSegments(item.content).reduce((max, segment) => Math.max(max, scoreSource(segment, query, keywords)), 0);
    const faqScore = ((_a = item.faqQuestions) != null ? _a : []).reduce((sum, question) => sum + scoreSource(question, query, keywords) * 2, 0);
    const hintScore = ((_b = item.answerHints) != null ? _b : []).reduce((sum, hint) => sum + scoreSource(hint, query, keywords), 0);
    return {
      item,
      score: corpusScore + segmentScore * 2 + faqScore + hintScore
    };
  }).filter((item) => item.score > 0).sort((left, right) => right.score - left.score).slice(0, 3).map((item) => item.item);
}
function toMatchedContentSourceReferences(items, query) {
  return items.map((item) => {
    var _a, _b;
    return {
      id: item.id,
      title: item.title,
      type: item.type,
      category: item.category,
      snippet: pickContentSourceSnippet(item, query),
      answerHints: (_b = (_a = item.answerHints) == null ? void 0 : _a.slice(0, 4)) != null ? _b : []
    };
  });
}
function pickContentSourceSnippet(item, query) {
  const compact = pickBestContentSegment(item, query).replace(/\s+/g, " ").trim();
  if (!compact) {
    return item.summary.trim();
  }
  const keywords = [query, ...extractKeywords(query)].map((value) => value.trim()).filter(Boolean);
  const matchedKeyword = keywords.find((keyword) => compact.toLowerCase().includes(keyword.toLowerCase()));
  if (!matchedKeyword) {
    return compact.slice(0, 120);
  }
  const index = compact.toLowerCase().indexOf(matchedKeyword.toLowerCase());
  const start = Math.max(0, index - 24);
  const end = Math.min(compact.length, index + matchedKeyword.length + 48);
  return compact.slice(start, end);
}
function scoreKnowledgeEntry(entry, query) {
  const keywords = extractKeywords(query);
  const normalizedQuery = normalizeText(query);
  const corpus = [entry.title, entry.oneLiner, entry.whatIs, ...entry.problems, ...entry.workflow, ...entry.scenarios, ...entry.outcomes].join(
    " "
  );
  let score = scoreSource(corpus, query, keywords);
  for (const keyword of entry.keywords) {
    const normalizedKeyword = normalizeText(keyword);
    if (normalizedKeyword && normalizedQuery.includes(normalizedKeyword)) {
      score += 8;
    }
  }
  return score;
}
function hasDirectKeywordHit(entry, query) {
  const normalizedQuery = normalizeText(query);
  if (!normalizedQuery) {
    return false;
  }
  return entry.keywords.some((keyword) => {
    const normalizedKeyword = normalizeText(keyword);
    return normalizedKeyword.length >= 2 && normalizedQuery.includes(normalizedKeyword);
  });
}
function pickKnowledgeEntry(query, knowledgeEntries) {
  const ranked = knowledgeEntries.map((entry) => {
    const baseScore = scoreKnowledgeEntry(entry, query);
    const priorityBoost = entry.source === "faq-standard-reply" && hasDirectKeywordHit(entry, query) ? 24 : 0;
    return { entry, score: baseScore + priorityBoost };
  }).sort((left, right) => right.score - left.score);
  const top = ranked[0];
  if (!top || top.score < 8) {
    return null;
  }
  return top.entry;
}
function buildKnowledgeAnswer(entry, question) {
  const lines = [
    "\u57FA\u4E8E\u5F53\u524D\u8D44\u6599\uFF0C\u7ED3\u6784\u5316\u7B54\u590D\u5982\u4E0B\uFF1A",
    `\u3010\u4F60\u7684\u95EE\u9898\u3011${question}`,
    `\u3010\u4E3B\u9898\u3011${entry.title}`,
    `\u3010\u4E00\u53E5\u8BDD\u3011${entry.oneLiner}`,
    `\u3010\u5B83\u662F\u4EC0\u4E48\u3011${entry.whatIs}`,
    "\u3010\u4E3B\u8981\u89E3\u51B3\u3011"
  ];
  entry.problems.forEach((item) => {
    lines.push(`- ${item}`);
  });
  lines.push("\u3010\u843D\u5730\u6D41\u7A0B\u3011");
  entry.workflow.forEach((item, index) => {
    lines.push(`${index + 1}. ${item}`);
  });
  lines.push("\u3010\u9002\u7528\u573A\u666F\u3011");
  entry.scenarios.forEach((item) => {
    lines.push(`- ${item}`);
  });
  lines.push("\u3010\u9884\u671F\u6548\u679C\u3011");
  entry.outcomes.forEach((item) => {
    lines.push(`- ${item}`);
  });
  lines.push("\u3010\u53C2\u8003\u8D44\u6599\u3011");
  lines.push(`- \u77E5\u8BC6\u6761\u76EE\uFF1A${entry.title}`);
  lines.push(`- \u6765\u6E90\uFF1A${entry.source}`);
  return lines.join("\n");
}
function formatConsultingPrice(item) {
  if (item.negotiable) {
    return "\u9762\u8BAE";
  }
  if (!item.price.trim()) {
    return "\u9762\u8BAE";
  }
  if (item.price.startsWith("\xA5") || item.price.startsWith("\uFFE5")) {
    return item.price;
  }
  return `\xA5${item.price}`;
}
function buildPriceAnswer(input) {
  const { query, products, consultingServices } = input;
  const matchedProducts = rankByQuery(products, query, (item) => `${item.name} ${item.category} ${item.summary}`).slice(0, 8);
  const matchedConsulting = rankByQuery(
    consultingServices,
    query,
    (item) => `${item.name} ${item.category} ${item.introduction}`
  ).slice(0, 5);
  if (matchedProducts.length === 0 && matchedConsulting.length === 0) {
    const examples = products.slice(0, 3).map((item) => item.name).join("\u3001");
    return `\u6682\u65E0\u7CBE\u786E\u5339\u914D\u3002\u4F60\u53EF\u4EE5\u8BD5\u8BD5\u8FD9\u4E9B\u793A\u4F8B\uFF1A${examples || "\u516D\u89D2\u5934\u87BA\u6813\u3001\u9AD8\u901F\u87BA\u4E1D\u673A"}\u3002`;
  }
  const lines = ["\u5DF2\u68C0\u7D22\u5230\u4EE5\u4E0B\u4EF7\u683C\u4FE1\u606F\uFF1A"];
  matchedProducts.forEach((item) => {
    var _a;
    lines.push(`- [${item.category}] ${item.name}\uFF1A${item.priceText}`);
    if ((_a = item.parameters) == null ? void 0 : _a.length) {
      lines.push(`  \u53C2\u6570\uFF1A${item.parameters.map((parameter) => `${parameter.label}=${parameter.value}`).join("\uFF1B")}`);
    }
  });
  matchedConsulting.forEach((item) => {
    lines.push(`- [\u54A8\u8BE2] ${item.name}\uFF1A${formatConsultingPrice(item)}`);
  });
  lines.push("\u3010\u53C2\u8003\u8D44\u6599\u3011");
  matchedProducts.forEach((item) => {
    lines.push(`- \u4EA7\u54C1\uFF1A${item.name}`);
  });
  matchedConsulting.forEach((item) => {
    lines.push(`- \u54A8\u8BE2\u670D\u52A1\uFF1A${item.name}`);
  });
  lines.push("\u5982\u9700\u6B63\u5F0F\u62A5\u4EF7\uFF0C\u8BF7\u63D0\u4EA4\u8054\u7CFB\u9700\u6C42\u3002");
  return lines.join("\n");
}
function buildDocumentAnswer(input) {
  const { query, knowledgeEntries, articles, products, consultingServices, contentSources, siteConfig } = input;
  const question = query.trim() || "\u8BF7\u4ECB\u7ECD\u4F60\u4EEC\u7684\u5E73\u53F0\u80FD\u529B";
  const matchedKnowledge = pickKnowledgeEntry(question, knowledgeEntries);
  if (matchedKnowledge) {
    const content2 = buildKnowledgeAnswer(matchedKnowledge, question);
    return { content: content2, meta: { strategy: "knowledge", matchedKnowledgeEntry: matchedKnowledge, matchedContentSources: [] } } ;
  }
  const matchedArticles = rankByQuery(articles, question, (item) => `${item.title} ${item.summary} ${item.category}`).slice(0, 3);
  const matchedProducts = rankByQuery(products, question, (item) => `${item.name} ${item.category} ${item.summary}`).slice(0, 3);
  const matchedConsulting = rankByQuery(
    consultingServices,
    question,
    (item) => `${item.name} ${item.category} ${item.introduction}`
  ).slice(0, 2);
  const matchedSources = pickMatchedContentSources(question, contentSources);
  const lines = [
    "\u57FA\u4E8E\u5F53\u524D\u8D44\u6599\uFF0C\u7ED3\u6784\u5316\u7B54\u590D\u5982\u4E0B\uFF1A",
    `\u3010\u4F60\u7684\u95EE\u9898\u3011${question}`,
    `\u3010\u5E73\u53F0\u5B9A\u4F4D\u3011${siteConfig.heroTitle}`,
    `\u3010\u670D\u52A1\u7B80\u4ECB\u3011${siteConfig.about}`
  ];
  if (matchedArticles.length === 0 && matchedProducts.length === 0 && matchedConsulting.length === 0 && matchedSources.length === 0) {
    lines.push("\u3010\u8BF4\u660E\u3011\u5F53\u524D\u8D44\u6599\u6CA1\u6709\u76F4\u63A5\u547D\u4E2D\u8BE5\u95EE\u9898\u3002\u53EF\u4EE5\u8865\u5145\u77E5\u8BC6\u6761\u76EE\u540E\u518D\u56DE\u7B54\u3002");
    const content2 = lines.join("\n");
    return { content: content2, meta: { strategy: "document", matchedKnowledgeEntry: null, matchedContentSources: [] } } ;
  }
  if (matchedArticles.length > 0) {
    lines.push("\u3010\u76F8\u5173\u6587\u6863\u6458\u8981\u3011");
    matchedArticles.forEach((item) => {
      lines.push(`- ${item.title}\uFF1A${item.summary}`);
    });
  }
  if (matchedProducts.length > 0) {
    lines.push("\u3010\u76F8\u5173\u4EA7\u54C1\u7EBF\u7D22\u3011");
    matchedProducts.forEach((item) => {
      var _a;
      lines.push(`- ${item.name}\uFF08${item.category}\uFF09\uFF1A${item.summary}`);
      if ((_a = item.parameters) == null ? void 0 : _a.length) {
        lines.push(`  \u53C2\u6570\uFF1A${item.parameters.map((parameter) => `${parameter.label}=${parameter.value}`).join("\uFF1B")}`);
      }
    });
  }
  if (matchedConsulting.length > 0) {
    lines.push("\u3010\u76F8\u5173\u54A8\u8BE2\u7EBF\u7D22\u3011");
    matchedConsulting.forEach((item) => {
      lines.push(`- ${item.name}\uFF1A${item.introduction}`);
    });
  }
  if (matchedSources.length > 0) {
    lines.push("\u3010\u76F8\u5173\u8D44\u6599\u6E90\u3011");
    matchedSources.forEach((item) => {
      var _a, _b;
      lines.push(`- [${formatContentSourceType(item.type)}] ${item.title}\uFF1A${item.summary}`);
      if ((_a = item.category) == null ? void 0 : _a.trim()) {
        lines.push(`  \u5206\u7C7B\uFF1A${item.category.trim()}`);
      }
      if ((_b = item.answerHints) == null ? void 0 : _b.length) {
        lines.push(`  \u56DE\u7B54\u8981\u70B9\uFF1A${item.answerHints.join("\uFF1B")}`);
      }
      const snippet = pickContentSourceSnippet(item, question);
      if (snippet) {
        lines.push(`  \u6458\u5F55\uFF1A${snippet}`);
      }
    });
  }
  lines.push("\u3010\u53C2\u8003\u8D44\u6599\u3011");
  matchedArticles.forEach((item) => {
    lines.push(`- \u6587\u6863\uFF1A${item.title}`);
  });
  matchedProducts.forEach((item) => {
    lines.push(`- \u4EA7\u54C1\uFF1A${item.name}`);
  });
  matchedConsulting.forEach((item) => {
    lines.push(`- \u54A8\u8BE2\u670D\u52A1\uFF1A${item.name}`);
  });
  matchedSources.forEach((item) => {
    const sourceRef = item.sourceUrl || item.sourceLabel || item.id;
    lines.push(`- ${formatContentSourceType(item.type)}\uFF1A${item.title} (${sourceRef})`);
  });
  const content = lines.join("\n");
  return { content, meta: { strategy: "document", matchedKnowledgeEntry: null, matchedContentSources: matchedSources } } ;
}
function looksLikePriceQuestion(query) {
  return /价格|报价|多少钱|费用|预算|采购价|单价/.test(query);
}
function buildAttachmentNotice(attachments) {
  if (!(attachments == null ? void 0 : attachments.length)) {
    return "";
  }
  const lines = ["\u3010\u5DF2\u6536\u5230\u9644\u4EF6\u3011"];
  attachments.forEach((attachment) => {
    lines.push(`- ${attachment.name}\uFF08${Math.max(1, Math.round(attachment.size / 1024))} KB\uFF09`);
  });
  lines.push("\u5F53\u524D MVP \u5DF2\u652F\u6301\u622A\u56FE\u968F\u4F1A\u8BDD\u7559\u5B58\uFF1B\u82E5\u9700\u56FE\u50CF\u8BC6\u522B\u7ED3\u8BBA\uFF0C\u8BF7\u7531\u5BA2\u670D\u8FDB\u4E00\u6B65\u5904\u7406\u6216\u63A5\u5165\u89C6\u89C9\u6A21\u578B\u3002");
  return lines.join("\n");
}
function buildAssistantReply(input) {
  let baseAnswer;
  let meta;
  if (looksLikePriceQuestion(input.query)) {
    baseAnswer = buildPriceAnswer({
      query: input.query,
      products: input.products,
      consultingServices: input.consultingServices
    });
    meta = { strategy: "price", matchedKnowledgeEntry: null, matchedContentSources: [] };
  } else {
    const documentResult = buildDocumentAnswer({ ...input});
    baseAnswer = documentResult.content;
    meta = documentResult.meta;
  }
  const attachmentNotice = buildAttachmentNotice(input.attachments);
  const content = [baseAnswer, attachmentNotice].filter(Boolean).join("\n\n");
  return input.returnMeta ? { content, meta } : content;
}

function createLlmAdapter(options) {
  return {
    async reply(input) {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      async function fallbackResult() {
        return {
          content: await options.fallback(input),
          model: options.model || "",
          inputTokens: 0,
          outputTokens: 0,
          totalTokens: 0,
          status: "fallback"
        };
      }
      if (!options.endpoint || !options.apiKey || !options.model) {
        return fallbackResult();
      }
      try {
        const fetcher = options.fetcher || fetch;
        const soul = options.soulProfile ? [
          options.soulProfile.role ? `\u89D2\u8272\uFF1A${options.soulProfile.role}` : "",
          options.soulProfile.tone ? `\u8BED\u6C14\uFF1A${options.soulProfile.tone}` : "",
          ((_a = options.soulProfile.goals) == null ? void 0 : _a.length) ? `\u76EE\u6807\uFF1A${options.soulProfile.goals.join("\uFF1B")}` : ""
        ].filter(Boolean).join("\n") : "";
        const messages = [
          {
            role: "system",
            content: [options.systemPrompt || "", soul].filter(Boolean).join("\n\n")
          },
          ...(input.history || []).map((item) => ({
            role: item.role,
            content: item.content
          })),
          {
            role: "user",
            content: [input.context || "", input.message].filter(Boolean).join("\n\n")
          }
        ];
        const response = await fetcher(options.endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${options.apiKey}`
          },
          body: JSON.stringify({
            model: options.model,
            messages
          })
        });
        if (!response.ok) {
          return fallbackResult();
        }
        const data = await response.json();
        const content = (_e = (_d = (_c = (_b = data.choices) == null ? void 0 : _b[0]) == null ? void 0 : _c.message) == null ? void 0 : _d.content) == null ? void 0 : _e.trim();
        if (!content) {
          return fallbackResult();
        }
        return {
          content,
          model: options.model,
          inputTokens: ((_f = data.usage) == null ? void 0 : _f.prompt_tokens) || 0,
          outputTokens: ((_g = data.usage) == null ? void 0 : _g.completion_tokens) || 0,
          totalTokens: ((_h = data.usage) == null ? void 0 : _h.total_tokens) || 0,
          status: "success"
        };
      } catch {
        return fallbackResult();
      }
    }
  };
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
class SessionNotFoundError extends Error {
  constructor(sessionId) {
    super(`Session not found: ${sessionId}`);
    __publicField(this, "code", "SESSION_NOT_FOUND");
    this.name = "SessionNotFoundError";
    Object.setPrototypeOf(this, SessionNotFoundError.prototype);
  }
}
function nextId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}
function normalizeQuestion(value) {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}
function buildRetrievalSystemPrompt(basePrompt, strategy) {
  const rules = [
    "\u4F60\u662F\u4F01\u4E1A\u5BA2\u670D\u95EE\u7B54\u52A9\u624B\u3002",
    "\u4F60\u5FC5\u987B\u4F18\u5148\u4F9D\u636E\u5DF2\u63D0\u4F9B\u7684\u547D\u4E2D\u8D44\u6599\u56DE\u7B54\uFF0C\u4E0D\u5F97\u8131\u79BB\u8D44\u6599\u81EA\u884C\u7F16\u9020\u4E8B\u5B9E\u3001\u53C2\u6570\u3001\u4EF7\u683C\u3001\u6D41\u7A0B\u6216\u627F\u8BFA\u3002",
    "\u82E5\u8D44\u6599\u5DF2\u7ECF\u7ED9\u51FA\u7ED3\u6784\u5316\u7ED3\u679C\uFF0C\u4F18\u5148\u4FDD\u7559\u8BE5\u7ED3\u6784\u5E76\u505A\u8F7B\u5EA6\u6DA6\u8272\uFF0C\u4E0D\u8981\u6539\u5199\u6210\u6563\u4E71\u957F\u6587\u3002",
    "\u82E5\u8D44\u6599\u672A\u76F4\u63A5\u547D\u4E2D\uFF0C\u53EA\u80FD\u660E\u786E\u8BF4\u660E\u201C\u5F53\u524D\u8D44\u6599\u672A\u76F4\u63A5\u547D\u4E2D\u201D\uFF0C\u5E76\u63D0\u793A\u53EF\u8865\u5145\u6587\u6863\u6216\u8F6C\u4EBA\u5DE5\uFF0C\u4E0D\u5F97\u81EA\u884C\u8111\u8865\u3002",
    "\u82E5\u95EE\u9898\u6D89\u53CA\u4EF7\u683C\uFF0C\u53EA\u80FD\u4F7F\u7528\u8D44\u6599\u4E2D\u5DF2\u6709\u4EF7\u683C\uFF1B\u6CA1\u6709\u7CBE\u786E\u4EF7\u683C\u65F6\u8981\u660E\u786E\u8BF4\u660E\u6682\u65E0\u7CBE\u786E\u5339\u914D\u3002",
    "\u56DE\u7B54\u4FDD\u6301\u7B80\u6D01\u3001\u4E13\u4E1A\u3001\u53EF\u6267\u884C\uFF0C\u907F\u514D\u7A7A\u6CDB\u5957\u8BDD\u3002"
  ];
  if (strategy === "knowledge") {
    rules.push("\u5F53\u524D\u95EE\u9898\u5DF2\u547D\u4E2D\u77E5\u8BC6\u6761\u76EE\u6216\u6807\u51C6\u56DE\u590D\uFF0C\u4F18\u5148\u6CBF\u7528\u8BE5\u53E3\u5F84\u3002");
  } else if (strategy === "price") {
    rules.push("\u5F53\u524D\u95EE\u9898\u662F\u4EF7\u683C/\u62A5\u4EF7\u95EE\u9898\uFF0C\u7981\u6B62\u8F93\u51FA\u8D44\u6599\u4E4B\u5916\u7684\u4EF7\u683C\u533A\u95F4\u6216\u4F30\u7B97\u3002");
  } else {
    rules.push("\u5F53\u524D\u95EE\u9898\u4F7F\u7528\u6587\u6863\u68C0\u7D22\u7ED3\u679C\u56DE\u7B54\uFF0C\u8BF7\u4F18\u5148\u5F15\u7528\u8D44\u6599\u6458\u8981\u3001\u4EA7\u54C1\u53C2\u6570\u548C\u8D44\u6599\u6458\u5F55\u3002");
  }
  return [(basePrompt == null ? void 0 : basePrompt.trim()) || "", rules.join("\n")].filter(Boolean).join("\n\n");
}
async function processChatMessage(input, options = {}) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
  const storage = options.storage || getStorage();
  const tenant = await resolveTenant(input.tenantId, storage);
  if (!tenant) {
    throw new TenantNotFoundError(input.tenantId);
  }
  const now = Date.now();
  let sessionId = input.sessionId;
  let history = [];
  const attachments = (_b = (_a = input.attachments) == null ? void 0 : _a.map((item) => structuredClone(item))) != null ? _b : [];
  if (sessionId) {
    const existingSession = await storage.getSessionById(sessionId);
    if (!existingSession || existingSession.tenantId !== tenant.id) {
      throw new SessionNotFoundError(sessionId);
    }
    const previousMessages = await storage.listMessagesBySession(sessionId);
    history = previousMessages.map((message) => {
      var _a2;
      return {
        role: message.role,
        content: ((_a2 = message.attachments) == null ? void 0 : _a2.length) ? `${message.content}
[\u9644\u4EF6: ${message.attachments.map((item) => item.name).join("\u3001")}]` : message.content
      };
    });
    await storage.saveSession({
      ...existingSession,
      lastMessageAt: now
    });
  } else {
    sessionId = nextId("session");
    await storage.saveSession({
      id: sessionId,
      tenantId: tenant.id,
      visitorId: "anonymous",
      startedAt: now,
      lastMessageAt: now
    });
  }
  const normalizedQuestion = normalizeQuestion(input.message);
  if (tenant.reuseAnsweredQuestions !== false) {
    const tenantSessions = await storage.listSessionsByTenant(tenant.id);
    for (const session of tenantSessions) {
      const sessionMessages = await storage.listMessagesBySession(session.id);
      for (let index = 0; index < sessionMessages.length - 1; index += 1) {
        const current = sessionMessages[index];
        const next = sessionMessages[index + 1];
        if (current.role === "user" && (next == null ? void 0 : next.role) === "assistant" && normalizeQuestion(current.content) === normalizedQuestion) {
          await storage.saveMessage({
            id: nextId("message"),
            sessionId,
            tenantId: tenant.id,
            role: "user",
            content: input.message,
            createdAt: now,
            attachments
          });
          await storage.saveMessage({
            id: nextId("message"),
            sessionId,
            tenantId: tenant.id,
            role: "assistant",
            content: next.content,
            createdAt: Date.now(),
            matchedContentSources: next.matchedContentSources
          });
          return {
            reply: next.content,
            sessionId,
            usage: {
              inputTokens: 0,
              outputTokens: 0,
              totalTokens: 0
            }
          };
        }
      }
    }
  }
  await storage.saveMessage({
    id: nextId("message"),
    sessionId,
    tenantId: tenant.id,
    role: "user",
    content: input.message,
    createdAt: now,
    attachments
  });
  const attachmentContext = attachments.length ? `\u7528\u6237\u672C\u8F6E\u4E0A\u4F20\u4E86\u9644\u4EF6\uFF1A${attachments.map((item) => `${item.name}(${item.mimeType}, ${Math.max(1, Math.round(item.size / 1024))}KB)`).join("\uFF1B")}` : "";
  const tenantContent = tenant.contentConfig;
  const activeContentSources = ((_c = tenantContent == null ? void 0 : tenantContent.contentSources) == null ? void 0 : _c.length) ? tenantContent.contentSources : [];
  const rawReplyContext = buildAssistantReply({
    query: input.message,
    knowledgeEntries: ((_d = tenantContent == null ? void 0 : tenantContent.knowledgeEntries) == null ? void 0 : _d.length) ? tenantContent.knowledgeEntries : assistantKnowledgeEntries,
    articles: ((_e = tenantContent == null ? void 0 : tenantContent.articles) == null ? void 0 : _e.length) ? tenantContent.articles : demoArticles,
    products: ((_f = tenantContent == null ? void 0 : tenantContent.products) == null ? void 0 : _f.length) ? tenantContent.products : demoProducts,
    consultingServices: ((_g = tenantContent == null ? void 0 : tenantContent.consultingServices) == null ? void 0 : _g.length) ? tenantContent.consultingServices : demoConsultingServices,
    contentSources: activeContentSources,
    siteConfig: {
      ...demoSiteConfig,
      brandName: tenant.brandName,
      phone: tenant.contactPhone || demoSiteConfig.phone,
      email: tenant.contactEmail || demoSiteConfig.email,
      address: tenant.contactAddress || demoSiteConfig.address
    },
    attachments,
    returnMeta: true
  });
  const replyContext = typeof rawReplyContext === "string" ? {
    content: rawReplyContext,
    meta: {
      strategy: "document",
      matchedKnowledgeEntry: null,
      matchedContentSources: []
    }
  } : {
    content: rawReplyContext.content,
    meta: {
      strategy: ((_h = rawReplyContext.meta) == null ? void 0 : _h.strategy) || "document",
      matchedKnowledgeEntry: ((_i = rawReplyContext.meta) == null ? void 0 : _i.matchedKnowledgeEntry) || null,
      matchedContentSources: ((_j = rawReplyContext.meta) == null ? void 0 : _j.matchedContentSources) || []
    }
  };
  const matchedContentSources = [
    ...((_k = replyContext.meta.matchedContentSources) == null ? void 0 : _k.length) ? toMatchedContentSourceReferences(replyContext.meta.matchedContentSources, input.message) : [],
    ...replyContext.meta.matchedKnowledgeEntry ? [{ id: `knowledge:${replyContext.meta.matchedKnowledgeEntry.title}`, title: replyContext.meta.matchedKnowledgeEntry.title, type: "document", category: replyContext.meta.strategy === "knowledge" ? "\u6807\u51C6\u56DE\u590D/\u77E5\u8BC6\u5E93" : "\u77E5\u8BC6\u547D\u4E2D" }] : []
  ];
  const adapter = createLlmAdapter({
    endpoint: tenant.llmEndpoint || options.endpoint,
    apiKey: tenant.llmApiKey || options.apiKey,
    model: tenant.llmModel || options.model,
    systemPrompt: buildRetrievalSystemPrompt(tenant.systemPrompt, replyContext.meta.strategy),
    fetcher: options.fetcher,
    fallback: async () => replyContext.content
  });
  const reply = await adapter.reply({
    message: input.message,
    history,
    context: [replyContext.content, attachmentContext].filter(Boolean).join("\n\n")
  });
  await storage.saveMessage({
    id: nextId("message"),
    sessionId,
    tenantId: tenant.id,
    role: "assistant",
    content: reply.content,
    createdAt: Date.now(),
    matchedContentSources
  });
  await storage.saveUsageRecord({
    id: nextId("usage"),
    tenantId: tenant.id,
    sessionId,
    provider: "openai-compatible",
    model: reply.model,
    inputTokens: reply.inputTokens,
    outputTokens: reply.outputTokens,
    totalTokens: reply.totalTokens,
    amount: "0",
    status: reply.status === "success" ? "success" : "unknown",
    createdAt: Date.now()
  });
  return {
    reply: reply.content,
    sessionId,
    usage: {
      inputTokens: reply.inputTokens,
      outputTokens: reply.outputTokens,
      totalTokens: reply.totalTokens
    }
  };
}

const chat_post = defineEventHandler(async (event) => {
  var _a, _b, _c;
  const runtimeConfig = useRuntimeConfig();
  const body = await readBody(event);
  const tenantId = (_a = body == null ? void 0 : body.tenantId) == null ? void 0 : _a.trim();
  const message = (_b = body == null ? void 0 : body.message) == null ? void 0 : _b.trim();
  if (!tenantId || !message) {
    throw createError({
      statusCode: 400,
      statusMessage: "tenantId and message are required"
    });
  }
  try {
    return await processChatMessage({
      tenantId,
      message,
      sessionId: (_c = body == null ? void 0 : body.sessionId) == null ? void 0 : _c.trim(),
      attachments: Array.isArray(body == null ? void 0 : body.attachments) ? body.attachments : []
    }, {
      endpoint: runtimeConfig.customerBotLlmEndpoint,
      apiKey: runtimeConfig.customerBotLlmApiKey,
      model: runtimeConfig.customerBotLlmModel
    });
  } catch (error) {
    if (error instanceof TenantNotFoundError) {
      throw createError({
        statusCode: 404,
        statusMessage: "Tenant not found"
      });
    }
    if (error instanceof SessionNotFoundError) {
      throw createError({
        statusCode: 404,
        statusMessage: "Session not found"
      });
    }
    throw error;
  }
});

export { chat_post as default };
//# sourceMappingURL=chat.post.mjs.map
