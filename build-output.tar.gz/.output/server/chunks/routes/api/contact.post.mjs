import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { g as getStorage } from '../../_/index.mjs';
import { r as resolveTenant } from '../../_/tenant-resolver.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const contact_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  if (!(body == null ? void 0 : body.tenantId) || !(body == null ? void 0 : body.name) || !body.company || !body.contact || !body.demandType) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u7F3A\u5C11\u5FC5\u586B\u5B57\u6BB5"
    });
  }
  const storage = getStorage();
  const tenant = await resolveTenant(body.tenantId, storage);
  if (!tenant) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  const leadId = `lead-${Date.now()}`;
  await storage.saveLead({
    id: leadId,
    tenantId: tenant.id,
    sessionId: body.sessionId || "",
    name: body.name,
    company: body.company,
    contact: body.contact,
    demandType: body.demandType,
    message: body.message || "",
    createdAt: Date.now()
  });
  return {
    ok: true,
    id: leadId,
    message: "\u63D0\u4EA4\u6210\u529F\uFF0C\u6211\u4EEC\u4F1A\u5728 1 \u4E2A\u5DE5\u4F5C\u65E5\u5185\u8054\u7CFB\u4F60\u3002"
  };
});

export { contact_post as default };
//# sourceMappingURL=contact.post.mjs.map
