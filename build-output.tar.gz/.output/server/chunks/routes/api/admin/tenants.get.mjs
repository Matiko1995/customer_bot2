import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const tenants_get = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const storage = getStorage();
  const query = getQuery(event);
  const includeDeleted = String(query.includeDeleted || "") === "1";
  const items = await storage.listTenants();
  return {
    items: includeDeleted ? items : items.filter((item) => !item.deletedAt)
  };
});

export { tenants_get as default };
//# sourceMappingURL=tenants.get.mjs.map
