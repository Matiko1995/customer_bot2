import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { c as createTenantLoginForTenant } from '../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

function nextTenantId() {
  return `tenant-${Date.now()}`;
}
const tenants_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
  requireAdminSession(event);
  const body = await readBody(event);
  const now = Date.now();
  const tenant = {
    id: ((_a = body.id) == null ? void 0 : _a.trim()) || nextTenantId(),
    name: ((_b = body.name) == null ? void 0 : _b.trim()) || "New Tenant",
    status: body.status === "disabled" ? "disabled" : "active",
    brandName: ((_c = body.brandName) == null ? void 0 : _c.trim()) || ((_d = body.name) == null ? void 0 : _d.trim()) || "New Tenant",
    themeColor: ((_e = body.themeColor) == null ? void 0 : _e.trim()) || "#118ab2",
    contactPhone: ((_f = body.contactPhone) == null ? void 0 : _f.trim()) || "",
    contactEmail: ((_g = body.contactEmail) == null ? void 0 : _g.trim()) || "",
    contactAddress: ((_h = body.contactAddress) == null ? void 0 : _h.trim()) || "",
    systemPrompt: ((_i = body.systemPrompt) == null ? void 0 : _i.trim()) || "You are the tenant bot.",
    llmEndpoint: ((_j = body.llmEndpoint) == null ? void 0 : _j.trim()) || "",
    llmApiKey: ((_k = body.llmApiKey) == null ? void 0 : _k.trim()) || "",
    llmModel: ((_l = body.llmModel) == null ? void 0 : _l.trim()) || "",
    reuseAnsweredQuestions: body.reuseAnsweredQuestions !== false,
    deletedAt: void 0,
    embedKey: ((_m = body.embedKey) == null ? void 0 : _m.trim()) || `embed-${Math.random().toString(36).slice(2, 10)}`,
    billingSubscription: (_n = body.billingSubscription) != null ? _n : {
      planId: "plan-basic",
      startedAt: now,
      notes: ""
    },
    contentConfig: body.contentConfig,
    createdAt: now,
    updatedAt: now
  };
  const storage = getStorage();
  await storage.saveTenant(tenant);
  const tenantLogin = await createTenantLoginForTenant({
    tenant,
    storage,
    now
  });
  return {
    ok: true,
    item: tenant,
    tenantLogin: {
      email: tenantLogin.user.email,
      initialPassword: tenantLogin.initialPassword,
      mustChangePassword: tenantLogin.user.mustChangePassword
    }
  };
});

export { tenants_post as default };
//# sourceMappingURL=tenants.post.mjs.map
