import { d as defineEventHandler, g as getQuery, c as createError } from '../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const leads_get = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const tenantId = typeof getQuery(event).tenantId === "string" ? String(getQuery(event).tenantId) : "";
  if (!tenantId) {
    throw createError({
      statusCode: 400,
      statusMessage: "tenantId is required"
    });
  }
  return {
    items: await getStorage().listLeadsByTenant(tenantId)
  };
});

export { leads_get as default };
//# sourceMappingURL=leads.get.mjs.map
