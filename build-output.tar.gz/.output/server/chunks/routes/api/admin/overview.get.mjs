import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { a as aggregateMatchedContentSourceStats } from '../../../_/content-ops.mjs';
import { r as requireAdminSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { b as buildMonthlyBillingSummary } from '../../../_/billing.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

function buildAdminOverview(input) {
  const tenantMap = new Map(input.tenants.map((tenant) => [tenant.id, tenant]));
  const activeHits = Array.from(input.contentStatsByTenant.values()).flat().reduce((sum, item) => sum + item.hits, 0);
  const recentlyActive = Array.from(
    new Map(
      input.sessions.sort((left, right) => right.lastMessageAt - left.lastMessageAt).map((session) => {
        const tenant = tenantMap.get(session.tenantId);
        return [
          session.tenantId,
          {
            tenantId: session.tenantId,
            tenantName: (tenant == null ? void 0 : tenant.name) || session.tenantId,
            lastMessageAt: session.lastMessageAt,
            status: (tenant == null ? void 0 : tenant.status) || "active"
          }
        ];
      })
    ).values()
  ).slice(0, 6);
  const priorityTenants = input.tenants.map((tenant) => {
    var _a;
    const latestBilling = input.billingSummaries.filter((item) => item.tenantId === tenant.id).sort((left, right) => right.month.localeCompare(left.month))[0];
    const contentStats = (_a = input.contentStatsByTenant.get(tenant.id)) != null ? _a : [];
    if (tenant.status === "disabled") {
      return { tenantId: tenant.id, tenantName: tenant.name, reason: "\u79DF\u6237\u5DF2\u505C\u7528", status: tenant.status };
    }
    if (((latestBilling == null ? void 0 : latestBilling.billableTokens) || 0) > 0) {
      return { tenantId: tenant.id, tenantName: tenant.name, reason: "\u5957\u9910\u5DF2\u4EA7\u751F\u8D85\u989D", status: tenant.status };
    }
    if (contentStats.length === 0) {
      return { tenantId: tenant.id, tenantName: tenant.name, reason: "\u6682\u65E0\u8D44\u6599\u547D\u4E2D", status: tenant.status };
    }
    return null;
  }).filter((item) => Boolean(item)).slice(0, 6);
  return {
    kpis: {
      todaySessions: input.sessions.length,
      todayLeads: input.leads.length,
      activeContentHits: activeHits,
      attentionTenants: priorityTenants.length
    },
    recentlyActive,
    priorityTenants
  };
}

const overview_get = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const storage = getStorage();
  const tenants = await storage.listTenants();
  const sessions = (await Promise.all(tenants.map((tenant) => storage.listSessionsByTenant(tenant.id)))).flat();
  const leads = (await Promise.all(tenants.map((tenant) => storage.listLeadsByTenant(tenant.id)))).flat();
  const usageRecords = (await Promise.all(tenants.map((tenant) => storage.listUsageByTenant(tenant.id)))).flat();
  const billingSummaries = buildMonthlyBillingSummary(usageRecords);
  const contentStatsByTenant = /* @__PURE__ */ new Map();
  for (const tenant of tenants) {
    const tenantSessions = await storage.listSessionsByTenant(tenant.id);
    const messageGroups = await Promise.all(tenantSessions.map((session) => storage.listMessagesBySession(session.id)));
    contentStatsByTenant.set(tenant.id, aggregateMatchedContentSourceStats(messageGroups.flat()));
  }
  return buildAdminOverview({
    tenants,
    sessions,
    leads,
    billingSummaries,
    contentStatsByTenant
  });
});

export { overview_get as default };
//# sourceMappingURL=overview.get.mjs.map
