import { d as defineEventHandler, g as getQuery, c as createError, s as setHeader } from '../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../_/auth.mjs';
import { g as getBillingPlanById } from '../../../_/billing-plans.mjs';
import { b as buildMonthlyBillingSummary, a as buildBillingCsv } from '../../../_/billing.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { r as resolveTenant } from '../../../_/tenant-resolver.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const billing_get = defineEventHandler(async (event) => {
  var _a;
  requireAdminSession(event);
  const query = getQuery(event);
  const tenantId = typeof query.tenantId === "string" ? String(query.tenantId) : "";
  if (!tenantId) {
    throw createError({
      statusCode: 400,
      statusMessage: "tenantId is required"
    });
  }
  const storage = getStorage();
  const tenant = await resolveTenant(tenantId, storage);
  const usageRecords = await storage.listUsageByTenant(tenantId);
  const plan = getBillingPlanById((_a = tenant == null ? void 0 : tenant.billingSubscription) == null ? void 0 : _a.planId);
  const summaries = buildMonthlyBillingSummary(usageRecords, plan, tenant == null ? void 0 : tenant.billingSubscription);
  if (query.format === "csv") {
    setHeader(event, "content-type", "text/csv; charset=utf-8");
    setHeader(event, "content-disposition", `attachment; filename="${tenantId}-billing.csv"`);
    return buildBillingCsv(summaries);
  }
  return {
    tenant,
    plan,
    usageRecords,
    summaries
  };
});

export { billing_get as default };
//# sourceMappingURL=billing.get.mjs.map
