import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { v as validateAdminCredentials, s as setAdminSession } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const login_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const email = ((_a = body == null ? void 0 : body.email) == null ? void 0 : _a.trim()) || "";
  const password = (body == null ? void 0 : body.password) || "";
  if (!validateAdminCredentials(email, password)) {
    throw createError({
      statusCode: 401,
      statusMessage: "Invalid credentials"
    });
  }
  setAdminSession(event);
  return {
    ok: true
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
