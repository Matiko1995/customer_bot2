import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../../_/auth.mjs';
import { g as getStorage } from '../../../../../_/index.mjs';
import { r as resolveTenant } from '../../../../../_/tenant-resolver.mjs';
import { T as TRAINING_PROVIDER } from '../../../../../_/training-runs.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const TRAINING_COST_PER_THOUSAND_TOKENS = 0.12;
const TRAINING_MODEL = "training-indexer-v1";
function buildTrainingCorpus(tenant) {
  var _a, _b, _c, _d, _e;
  const content = tenant.contentConfig;
  if (!content) {
    return [];
  }
  const enabledSources = ((_a = content.contentSources) != null ? _a : []).filter((item) => item.enabled !== false);
  const sourceTexts = enabledSources.map(
    (item) => {
      var _a2;
      return [item.title, item.summary, item.content, item.sourceLabel, item.sourceUrl, ...(_a2 = item.tags) != null ? _a2 : []].filter(Boolean).join("\n");
    }
  );
  const knowledgeTexts = ((_b = content.knowledgeEntries) != null ? _b : []).map(
    (item) => [
      item.title,
      item.oneLiner,
      item.whatIs,
      item.source,
      ...item.keywords,
      ...item.problems,
      ...item.workflow,
      ...item.scenarios,
      ...item.outcomes
    ].filter(Boolean).join("\n")
  );
  const articleTexts = ((_c = content.articles) != null ? _c : []).map((item) => [item.title, item.category, item.summary].filter(Boolean).join("\n"));
  const productTexts = ((_d = content.products) != null ? _d : []).map(
    (item) => {
      var _a2;
      return [item.name, item.category, item.summary, item.priceText, ...((_a2 = item.parameters) != null ? _a2 : []).map((param) => `${param.label}:${param.value}`)].filter(Boolean).join("\n");
    }
  );
  const serviceTexts = ((_e = content.consultingServices) != null ? _e : []).map(
    (item) => [item.name, item.category, item.introduction, item.price, item.negotiable ? "negotiable" : "fixed"].filter(Boolean).join("\n")
  );
  return [...sourceTexts, ...knowledgeTexts, ...articleTexts, ...productTexts, ...serviceTexts].map((item) => item.trim()).filter(Boolean);
}
function toMoney(value) {
  return value.toFixed(2);
}
function estimateTrainingRun(tenant) {
  var _a, _b, _c;
  const corpus = buildTrainingCorpus(tenant);
  const sourceCount = (_c = (_b = (_a = tenant.contentConfig) == null ? void 0 : _a.contentSources) == null ? void 0 : _b.filter((item) => item.enabled !== false).length) != null ? _c : 0;
  if (!corpus.length) {
    throw new Error("\u5F53\u524D\u79DF\u6237\u6CA1\u6709\u53EF\u8BAD\u7EC3\u5185\u5BB9\uFF0C\u8BF7\u5148\u6DFB\u52A0\u8D44\u6599\u6E90\u6216\u5185\u5BB9\u914D\u7F6E");
  }
  const characterCount = corpus.reduce((sum, item) => sum + item.length, 0);
  const assetCount = corpus.length;
  const inputTokens = Math.max(256, Math.ceil(characterCount / 4) + assetCount * 48);
  const outputTokens = Math.max(96, Math.ceil(inputTokens * 0.08));
  const totalTokens = inputTokens + outputTokens;
  const amount = toMoney(totalTokens / 1e3 * TRAINING_COST_PER_THOUSAND_TOKENS);
  return {
    sourceCount,
    assetCount,
    characterCount,
    inputTokens,
    outputTokens,
    totalTokens,
    amount
  };
}
async function simulateTenantTraining(input) {
  var _a;
  const createdAt = (_a = input.now) != null ? _a : Date.now();
  const estimate = estimateTrainingRun(input.tenant);
  const record = {
    id: `usage-training-${createdAt}`,
    tenantId: input.tenant.id,
    sessionId: `training-${input.tenant.id}-${createdAt}`,
    provider: TRAINING_PROVIDER,
    model: TRAINING_MODEL,
    inputTokens: estimate.inputTokens,
    outputTokens: estimate.outputTokens,
    totalTokens: estimate.totalTokens,
    amount: estimate.amount,
    status: "success",
    createdAt
  };
  await input.storage.saveUsageRecord(record);
  return {
    ...estimate,
    record
  };
}

const training_post = defineEventHandler(async (event) => {
  var _a;
  requireAdminSession(event);
  const tenantId = (_a = getRouterParam(event, "tenantId")) == null ? void 0 : _a.trim();
  if (!tenantId) {
    throw createError({
      statusCode: 400,
      statusMessage: "tenantId is required"
    });
  }
  const storage = getStorage();
  const tenant = await resolveTenant(tenantId, storage);
  if (!tenant) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  try {
    return await simulateTenantTraining({
      tenant,
      storage
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "\u8BAD\u7EC3\u6A21\u62DF\u5931\u8D25";
    throw createError({
      statusCode: 400,
      statusMessage: message
    });
  }
});

export { training_post as default };
//# sourceMappingURL=training.post.mjs.map
