import { d as defineEventHandler, a as getRouterParam, c as createError, r as readBody } from '../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../_/auth.mjs';
import { g as getStorage } from '../../../../_/index.mjs';
import { r as resolveTenant } from '../../../../_/tenant-resolver.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const _tenantId__put = defineEventHandler(async (event) => {
  var _a, _b, _c;
  requireAdminSession(event);
  const tenantIdentifier = getRouterParam(event, "tenantId") || "";
  const storage = getStorage();
  const existing = await resolveTenant(tenantIdentifier, storage);
  if (!existing) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  const body = await readBody(event);
  const updated = {
    ...existing,
    ...body,
    llmEndpoint: body.llmEndpoint !== void 0 ? ((_a = body.llmEndpoint) == null ? void 0 : _a.trim()) || "" : existing.llmEndpoint,
    llmApiKey: body.llmApiKey !== void 0 ? ((_b = body.llmApiKey) == null ? void 0 : _b.trim()) || "" : existing.llmApiKey,
    llmModel: body.llmModel !== void 0 ? ((_c = body.llmModel) == null ? void 0 : _c.trim()) || "" : existing.llmModel,
    reuseAnsweredQuestions: body.reuseAnsweredQuestions !== void 0 ? body.reuseAnsweredQuestions !== false : existing.reuseAnsweredQuestions,
    id: existing.id,
    embedKey: existing.embedKey,
    createdAt: existing.createdAt,
    updatedAt: Date.now()
  };
  await storage.saveTenant(updated);
  return {
    ok: true,
    item: updated
  };
});

export { _tenantId__put as default };
//# sourceMappingURL=_tenantId_.put.mjs.map
