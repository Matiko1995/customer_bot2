import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../_/auth.mjs';
import { g as getStorage } from '../../../../_/index.mjs';
import { r as resolveTenant } from '../../../../_/tenant-resolver.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const _tenantId__get = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const tenantId = getRouterParam(event, "tenantId") || "";
  const storage = getStorage();
  const tenant = await resolveTenant(tenantId, storage);
  if (!tenant) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  return {
    item: tenant,
    tenantUsers: await storage.listTenantUsersByTenant(tenant.id)
  };
});

export { _tenantId__get as default };
//# sourceMappingURL=_tenantId_.get.mjs.map
