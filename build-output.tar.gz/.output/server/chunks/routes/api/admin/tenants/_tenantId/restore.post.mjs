import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../../_/auth.mjs';
import { g as getStorage } from '../../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const restore_post = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const tenantId = getRouterParam(event, "tenantId") || "";
  const storage = getStorage();
  const tenant = await storage.getTenantById(tenantId);
  if (!tenant) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  await storage.saveTenant({
    ...tenant,
    status: "active",
    deletedAt: void 0,
    updatedAt: Date.now()
  });
  return { ok: true };
});

export { restore_post as default };
//# sourceMappingURL=restore.post.mjs.map
