import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../../_/auth.mjs';
import { s as sendTenantResetEmail } from '../../../../../_/mailer.mjs';
import { g as getStorage } from '../../../../../_/index.mjs';
import { r as resolveTenant } from '../../../../../_/tenant-resolver.mjs';
import { i as issueTenantPasswordReset } from '../../../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const resetCode_post = defineEventHandler(async (event) => {
  var _a, _b;
  requireAdminSession(event);
  const tenantId = ((_a = getRouterParam(event, "tenantId")) == null ? void 0 : _a.trim()) || "";
  const storage = getStorage();
  const tenant = await resolveTenant(tenantId, storage);
  if (!tenant) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  const email = (_b = tenant.contactEmail) == null ? void 0 : _b.trim();
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Tenant contact email is required"
    });
  }
  const reset = await issueTenantPasswordReset({
    email,
    storage
  });
  const sent = await sendTenantResetEmail({
    to: reset.email,
    code: reset.code,
    expiresAt: reset.expiresAt,
    tenantName: tenant.name,
    loginUrl: `${(process.env.CUSTOMER_BOT_PUBLIC_BASE_URL || "https://bot.aifactory.website").replace(/\/+$/, "")}/tenant/login`
  });
  return {
    ok: true,
    item: {
      email: reset.email,
      expiresAt: reset.expiresAt,
      provider: sent.provider,
      previewCode: sent.previewCode
    }
  };
});

export { resetCode_post as default };
//# sourceMappingURL=reset-code.post.mjs.map
