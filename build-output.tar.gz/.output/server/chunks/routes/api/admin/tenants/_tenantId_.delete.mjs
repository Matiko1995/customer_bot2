import { d as defineEventHandler, a as getRouterParam, c as createError } from '../../../../nitro/nitro.mjs';
import { r as requireAdminSession } from '../../../../_/auth.mjs';
import { g as getStorage } from '../../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const _tenantId__delete = defineEventHandler(async (event) => {
  requireAdminSession(event);
  const tenantId = getRouterParam(event, "tenantId") || "";
  const storage = getStorage();
  const tenant = await storage.getTenantById(tenantId);
  if (!tenant || tenant.deletedAt) {
    throw createError({
      statusCode: 404,
      statusMessage: "Tenant not found"
    });
  }
  const updatedAt = Date.now();
  await storage.saveTenant({
    ...tenant,
    status: "disabled",
    deletedAt: updatedAt,
    updatedAt
  });
  return { ok: true };
});

export { _tenantId__delete as default };
//# sourceMappingURL=_tenantId_.delete.mjs.map
