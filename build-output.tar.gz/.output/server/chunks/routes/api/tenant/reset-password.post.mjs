import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { b as setTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { r as resetTenantPassword } from '../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const resetPassword_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event);
  const email = ((_a = body == null ? void 0 : body.email) == null ? void 0 : _a.trim()) || "";
  const code = ((_b = body == null ? void 0 : body.code) == null ? void 0 : _b.trim()) || "";
  const nextPassword = (body == null ? void 0 : body.nextPassword) || "";
  if (!email || !code || !nextPassword) {
    throw createError({
      statusCode: 400,
      statusMessage: "email, code and nextPassword are required"
    });
  }
  const user = await resetTenantPassword({
    email,
    code,
    nextPassword,
    storage: getStorage()
  });
  setTenantSession(event, {
    tenantUserId: user.id,
    tenantId: user.tenantId,
    email: user.email
  });
  return {
    ok: true,
    user: {
      email: user.email,
      tenantId: user.tenantId,
      mustChangePassword: user.mustChangePassword
    }
  };
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
