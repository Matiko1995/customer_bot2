import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { a as requireTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { v as verifyTenantPassword } from '../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const changePassword_post = defineEventHandler(async (event) => {
  const session = requireTenantSession(event);
  const body = await readBody(event);
  const currentPassword = (body == null ? void 0 : body.currentPassword) || "";
  const nextPassword = (body == null ? void 0 : body.nextPassword) || "";
  if (!currentPassword || !nextPassword) {
    throw createError({
      statusCode: 400,
      statusMessage: "currentPassword and nextPassword are required"
    });
  }
  const storage = getStorage();
  const user = await verifyTenantPassword(session.email, currentPassword, storage);
  if (!user || user.id !== session.tenantUserId) {
    throw createError({
      statusCode: 401,
      statusMessage: "Invalid credentials"
    });
  }
  const updatedUser = {
    ...user,
    passwordHash: user.passwordHash,
    temporaryPassword: "",
    mustChangePassword: false,
    updatedAt: Date.now()
  };
  const { createHash } = await import('node:crypto');
  updatedUser.passwordHash = createHash("sha256").update(nextPassword).digest("hex");
  await storage.saveTenantUser(updatedUser);
  return {
    ok: true
  };
});

export { changePassword_post as default };
//# sourceMappingURL=change-password.post.mjs.map
