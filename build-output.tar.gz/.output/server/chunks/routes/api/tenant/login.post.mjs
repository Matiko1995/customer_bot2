import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { b as setTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { v as verifyTenantPassword } from '../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const login_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const email = ((_a = body == null ? void 0 : body.email) == null ? void 0 : _a.trim()) || "";
  const password = (body == null ? void 0 : body.password) || "";
  const user = await verifyTenantPassword(email, password, getStorage());
  if (!user) {
    throw createError({
      statusCode: 401,
      statusMessage: "Invalid credentials"
    });
  }
  setTenantSession(event, {
    tenantUserId: user.id,
    tenantId: user.tenantId,
    email: user.email
  });
  return {
    ok: true,
    user: {
      email: user.email,
      tenantId: user.tenantId,
      mustChangePassword: user.mustChangePassword
    }
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
