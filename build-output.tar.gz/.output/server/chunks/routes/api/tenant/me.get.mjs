import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { a as requireTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const me_get = defineEventHandler(async (event) => {
  const session = requireTenantSession(event);
  const storage = getStorage();
  const user = await storage.getTenantUserById(session.tenantUserId);
  const tenant = await storage.getTenantById(session.tenantId);
  if (!user || !tenant || user.status !== "active") {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  return {
    user: {
      id: user.id,
      email: user.email,
      tenantId: user.tenantId,
      mustChangePassword: user.mustChangePassword
    },
    tenant
  };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
