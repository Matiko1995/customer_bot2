import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { g as getBillingPlanById } from '../../../_/billing-plans.mjs';
import { l as listTrainingRuns } from '../../../_/training-runs.mjs';
import { a as requireTenantSession } from '../../../_/auth.mjs';
import { b as buildMonthlyBillingSummary } from '../../../_/billing.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const overview_get = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const session = requireTenantSession(event);
  const storage = getStorage();
  const tenant = await storage.getTenantById(session.tenantId);
  const user = await storage.getTenantUserById(session.tenantUserId);
  if (!tenant || !user || user.status !== "active") {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const [sessions, leads, usageRecords] = await Promise.all([
    storage.listSessionsByTenant(tenant.id),
    storage.listLeadsByTenant(tenant.id),
    storage.listUsageByTenant(tenant.id)
  ]);
  const plan = getBillingPlanById((_a = tenant.billingSubscription) == null ? void 0 : _a.planId);
  const summaries = buildMonthlyBillingSummary(usageRecords, plan, tenant.billingSubscription);
  return {
    tenant: {
      id: tenant.id,
      name: tenant.name,
      brandName: tenant.brandName,
      contactEmail: tenant.contactEmail
    },
    user: {
      email: user.email,
      mustChangePassword: user.mustChangePassword
    },
    kpis: {
      sessionCount: sessions.length,
      leadCount: leads.length,
      contentSourceCount: (_d = (_c = (_b = tenant.contentConfig) == null ? void 0 : _b.contentSources) == null ? void 0 : _c.length) != null ? _d : 0
    },
    trainingRuns: listTrainingRuns(usageRecords).slice(0, 10),
    latestBillingSummary: summaries[summaries.length - 1] || null
  };
});

export { overview_get as default };
//# sourceMappingURL=overview.get.mjs.map
