import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { s as sortTenantLeads } from '../../../_/tenant-readonly.mjs';
import { a as requireTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const leads_get = defineEventHandler(async (event) => {
  const session = requireTenantSession(event);
  const storage = getStorage();
  const user = await storage.getTenantUserById(session.tenantUserId);
  if (!user || user.status !== "active" || user.tenantId !== session.tenantId) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  return {
    items: sortTenantLeads(await storage.listLeadsByTenant(session.tenantId))
  };
});

export { leads_get as default };
//# sourceMappingURL=leads.get.mjs.map
