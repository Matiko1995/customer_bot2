import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import { s as sendTenantResetEmail } from '../../../_/mailer.mjs';
import { i as issueTenantPasswordReset } from '../../../_/tenant-users.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const resetCode_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const email = ((_a = body == null ? void 0 : body.email) == null ? void 0 : _a.trim()) || "";
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "email is required"
    });
  }
  const reset = await issueTenantPasswordReset({
    email,
    storage: getStorage()
  });
  const sent = await sendTenantResetEmail({
    to: reset.email,
    code: reset.code,
    expiresAt: reset.expiresAt,
    tenantName: reset.tenantId,
    loginUrl: `${(process.env.CUSTOMER_BOT_PUBLIC_BASE_URL || "https://bot.aifactory.website").replace(/\/+$/, "")}/tenant/login`
  });
  return {
    ok: true,
    item: {
      email: reset.email,
      expiresAt: reset.expiresAt,
      provider: sent.provider,
      previewCode: sent.previewCode
    }
  };
});

export { resetCode_post as default };
//# sourceMappingURL=reset-code.post.mjs.map
