import { d as defineEventHandler, c as createError } from '../../../nitro/nitro.mjs';
import { b as buildTenantChatItems } from '../../../_/tenant-readonly.mjs';
import { a as requireTenantSession } from '../../../_/auth.mjs';
import { g as getStorage } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:fs/promises';

const chats_get = defineEventHandler(async (event) => {
  const session = requireTenantSession(event);
  const storage = getStorage();
  const user = await storage.getTenantUserById(session.tenantUserId);
  if (!user || user.status !== "active" || user.tenantId !== session.tenantId) {
    throw createError({
      statusCode: 401,
      statusMessage: "Unauthorized"
    });
  }
  const sessions = await storage.listSessionsByTenant(session.tenantId);
  const messagesBySession = new Map(
    await Promise.all(
      sessions.map(async (chatSession) => [chatSession.id, await storage.listMessagesBySession(chatSession.id)])
    )
  );
  return {
    items: buildTenantChatItems(sessions, messagesBySession)
  };
});

export { chats_get as default };
//# sourceMappingURL=chats.get.mjs.map
