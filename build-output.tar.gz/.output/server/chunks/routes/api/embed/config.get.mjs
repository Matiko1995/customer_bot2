import { d as defineEventHandler, g as getQuery, c as createError } from '../../../nitro/nitro.mjs';
import { g as getRuntimeConfigForTenant, T as TenantNotFoundError } from '../../../_/tenants.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/index.mjs';
import 'node:fs/promises';
import '../../../_/tenant-resolver.mjs';

const config_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const tenantId = typeof query.tenantId === "string" ? query.tenantId.trim() : "";
  if (!tenantId) {
    throw createError({
      statusCode: 400,
      statusMessage: "tenantId is required"
    });
  }
  try {
    return await getRuntimeConfigForTenant(tenantId);
  } catch (error) {
    if (error instanceof TenantNotFoundError) {
      throw createError({
        statusCode: 404,
        statusMessage: "Tenant not found"
      });
    }
    throw error;
  }
});

export { config_get as default };
//# sourceMappingURL=config.get.mjs.map
